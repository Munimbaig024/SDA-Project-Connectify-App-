---------Messages Table ----------
CREATE TABLE Messages (
    msgID      INT PRIMARY KEY,         -- Unique identifier for each message
    text       CLOB,                    -- Text content of the message, with maximum allowable length
    senderID   INT                     -- ID of the sender 
) TABLESPACE USERS;

select * from Messages;

INSERT INTO Messages (msgID, text, senderID)
VALUES (1, 'Hello, how are you?', 1);

INSERT INTO Messages (msgID, text, senderID)
VALUES (2, 'I am doing well, thank you. How about you?', 2);

INSERT INTO Messages (msgID, text, senderID)
VALUES (3, 'I am doing good too. What are you working on these days?', 1);

INSERT INTO Messages (msgID, text, senderID)
VALUES (4, 'I am currently working on a new web development project.', 2);

INSERT INTO Messages (msgID, text, senderID)
VALUES (5, 'That sounds exciting! Let me know if you need any help.', 1);


ALTER TABLE Messages 
ADD conversationID INT;


--DROP TABLE Messages CASCADE CONSTRAINTS;


-------------------------------------------------


---------Conversation Table ----------
CREATE TABLE Conversation (
    conversationID   INT PRIMARY KEY,         -- Unique identifier for each conversation
    userAID          INT NOT NULL,            -- ID of the first user in the conversation
    userBID          INT NOT NULL            -- ID of the second user in the conversation

) TABLESPACE USERS;

delete from Conversation
DROP TABLE Conversation;


select * from Conversation ; 

INSERT INTO Conversation (conversationID, userAID, userBID)
VALUES (1, 1, 2);

delete from Messages;
delete from Conversation;



---------Event Table ----------
CREATE TABLE Events (
    event_ID      INT PRIMARY KEY,            -- Unique identifier for each event
    user_ID       INT NOT NULL,               -- ID of the user who created the event
    name          VARCHAR2(100) NOT NULL,     -- Name of the event
    description   VARCHAR2(500),              -- Description of the event
    eventDateTime TIMESTAMP NOT NULL,         -- Date and time of the event
    location      VARCHAR2(200)               -- Location of the event
) TABLESPACE USERS;



select * from Events;



-------User Table -----------
CREATE TABLE Users (
    userID      INT PRIMARY KEY,         -- Unique identifier for each user
    name        VARCHAR2(100) NOT NULL,  -- User's name
    email       VARCHAR2(100) UNIQUE NOT NULL, -- User's email
    password    VARCHAR2(50) NOT NULL,   -- User's password (hashed in real use cases)
    createdAt   TIMESTAMP NOT NULL, -- Timestamp when the user was created
    userType    VARCHAR2(20) NOT NULL CHECK (userType IN ('Startup', 'BiggerCompany')), -- Type of user
    industry    VARCHAR2(100),          -- Industry (nullable)
    teamSize    INT                     -- Team size (nullable)
) TABLESPACE USERS;

select * from Users;

-- Insert a Startup User
INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (1, 'Talha', 'talha@gmail.com', '12345', SYSDATE, 'Startup', 'Technology', 5);

INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (3, 'Talha', 'talha', '123', SYSDATE, 'Startup', 'Technology', 5);

INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (4, 'Talha', 't', '123', SYSDATE, 'Startup', 'Technology', 5);

INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (5, 'muni', 'muni', '123', SYSDATE, 'Startup', 'Technology', 5);

INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (6, 'hadi', 'hadi', '123', SYSDATE, 'Startup', 'Technology', 10);

-- Insert a Bigger Company User
INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize)
VALUES (2, 'Munim', 'munim@gamil.com', '12345', SYSDATE, 'BiggerCompany', 'Finance', 200);

delete from Users;



-------- Job Table --------------

CREATE TABLE Jobs (
    jobID       INT PRIMARY KEY,              -- Unique identifier for each job
    userID      INT NOT NULL,                 -- ID of the user who posted the job
    title       VARCHAR2(100) NOT NULL,       -- Job title
    description CLOB ,               -- Job description
    category    VARCHAR2(50) NOT NULL,        -- Job category
    status      VARCHAR2(20) NOT NULL CHECK (status IN ('Open', 'Closed', 'In Progress')) -- Job status
   
) TABLESPACE USERS;


select * from Jobs ;


INSERT INTO Jobs (jobID, userID, title, description, category, status)
VALUES (1, 2, 'Front-End Web Developer', 'Develop user-friendly and visually appealing websites.', 'Web Development', 'Open');

INSERT INTO Jobs (jobID, userID, title, description, category, status)
VALUES (2, 2, 'Back-End Web Developer', 'Build robust and scalable server-side applications.', 'Web Development', 'Open');

INSERT INTO Jobs (jobID, userID, title, description, category, status)
VALUES (3, 2, 'Full-Stack Web Developer', 'Design, develop, and deploy complete web applications.', 'Web Development', 'Open');

INSERT INTO Jobs (jobID, userID, title, description, category, status)
VALUES (4, 2, 'Web Designer', 'Create visually appealing website layouts and designs.', 'Web Development', 'Open');

INSERT INTO Jobs (jobID, userID, title, description, category, status)
VALUES (5, 2, 'UI/UX Designer', 'Design user-friendly and intuitive user interfaces.', 'Web Development', 'Open');

UPDATE Jobs
SET userID = 2
WHERE userID = 1;


delete from Jobs ;

drop table Jobs ;

SELECT LENGTH(description) AS clob_length
FROM Jobs
WHERE jobID = 1;



------ Job Application Table -----------

-- A single Job will have multiple Applications submitted to it. 

CREATE TABLE JobApplications (
    applicantID    INT NOT NULL,              -- ID of the applicant (user ID)
    jobID          INT NOT NULL,              -- ID of the job being applied for
    startupID      INT NOT NULL,              -- ID of the startup (user ID who owns the job)
    coverLetter    VARCHAR2(2000),            -- Cover letter content
    submittedDate  DATE NOT NULL,             -- Date the application was submitted
    status         CHAR(1) DEFAULT 'F' CHECK (status IN ('T', 'F')) -- T: Accepted, F: Pending/Rejected : there is no boolean in Oracle 
 
) TABLESPACE USERS;


select * from JobApplications ; 

delete from JobApplications ; 



---------- Financial data --------
CREATE TABLE FinancialData (
    financialID       INT PRIMARY KEY,                     -- Unique identifier for financial data
    userID            INT NOT NULL,                       -- ID of the user associated with this financial data
    cumulativeIncome  INT NOT NULL,                       -- Total income accumulated
    cumulativeExpenses INT NOT NULL,                      -- Total expenses accumulated
    profitOrLoss      INT NOT NULL,                       -- Calculated profit or loss
    progressGraph     CLOB                                -- Stores the progress graph as a string (e.g., encoded data)
    
) TABLESPACE USERS;

-- Insert cumulative financial data into FinancialData table
INSERT INTO FinancialData (financialID, userID, cumulativeIncome, cumulativeExpenses, profitOrLoss, progressGraph)
VALUES (
    1 ,                           -- financialID
    1 ,                           -- userID (assuming 1 for this example)
    (SELECT SUM(income) FROM FinancialEntry WHERE financialID = 1),         -- cumulativeIncome
    (SELECT SUM(expenses) FROM FinancialEntry WHERE financialID = 1),       -- cumulativeExpenses
    (SELECT SUM(profitOrLoss) FROM FinancialEntry WHERE financialID = 1),   -- cumulative profit or loss
    NULL                         -- progressGraph (can be updated later)
);

select * from FinancialData ;
delete from FinancialData ;


drop table FinancialData ;
drop table FinacialEntry; 


---- Financial Entry ------

CREATE TABLE FinancialEntry (
    entryID           INT PRIMARY KEY,                     -- Unique identifier for the financial entry
    financialID       INT NOT NULL,                       -- Foreign key linking to FinancialData
    expenses          INT NOT NULL,                       -- Entry's expense value
    income            INT NOT NULL,                       -- Entry's income value
    profitOrLoss      INT NOT NULL,                       -- Profit or loss calculated for this entry
    entryDate         TIMESTAMP NOT NULL                 -- Date of the financial entry
) TABLESPACE USERS;


-- Insert query for one month in 2023
INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (14 , 1, 1000, 1500, 500, TO_TIMESTAMP('2023-12-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

-- Insert queries for every month of 2024
INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (2, 1, 1100, 1600, 500, TO_TIMESTAMP('2024-01-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (3, 1, 1200, 1500, 300, TO_TIMESTAMP('2024-02-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (4, 1, 1300, 2000, 700, TO_TIMESTAMP('2024-03-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (5, 1, 1400, 1900, 500, TO_TIMESTAMP('2024-04-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (6, 1, 1500, 2000, 500, TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (7, 1, 1600, 1600, 0, TO_TIMESTAMP('2024-06-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (8, 1, 1700, 4200, 2500, TO_TIMESTAMP('2024-07-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (9, 1, 1800, 2500, 700, TO_TIMESTAMP('2024-08-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (10, 1, 1900, 1800, -100 , TO_TIMESTAMP('2024-09-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (11, 1, 2000, 5500, 3500, TO_TIMESTAMP('2024-10-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (12, 1, 2100, 3600, 1500, TO_TIMESTAMP('2024-11-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate)
VALUES (13, 1, 2200, 2900, 700, TO_TIMESTAMP('2024-12-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));




DELETE FROM FinancialEntry WHERE entryID != 1;


SELECT * FROM FinancialEntry;


SELECT PROFITORLOSS , entryDate
FROM FinancialEntry 
WHERE financialID = 1 
  AND EXTRACT(MONTH FROM entryDate) IN ( 1, 2, 3, 4 )
  AND EXTRACT(YEAR FROM entryDate) = 2024;

delete from FinancialEntry ;

---------- Goals -------------

CREATE TABLE Goals (
    goalID          INT PRIMARY KEY,            -- Unique identifier for the goal
    userID          INT NOT NULL,              -- Foreign key linking to User table
    description     VARCHAR2(255) NOT NULL,    -- Goal description
    deadline        TIMESTAMP NOT NULL,        -- Deadline for achieving the goal
    financialGoal   INT NOT NULL              -- Financial target for the goal
    
) TABLESPACE USERS;


select * from Goals ;

delete from Goals ;



----------Services Table ---------------

CREATE TABLE Services (
    serviceID     INT PRIMARY KEY,           -- Unique identifier for the service
    userID        INT NOT NULL,              -- Foreign key linking to User table
    name          VARCHAR2(100) NOT NULL,    -- Service name
    description   CLOB,                      -- Detailed description of the service
    category      VARCHAR2(50),              -- Category of the service
    basePrice     INT NOT NULL,              -- Base price for the service
    status        VARCHAR2(20) NOT NULL      -- Status (e.g., "Active", "Inactive")

) TABLESPACE USERS;

select * from Services ;

delete from Services ;

drop Table Services ;

INSERT INTO Services (serviceID, userID, name, description, category, basePrice, status)
VALUES (1, 1, 'Web Design', 'Create stunning and responsive websites.', 'Web Development', 500, 'Active');

INSERT INTO Services (serviceID, userID, name, description, category, basePrice, status)
VALUES (2, 1, 'E-commerce Website', 'Build online stores with secure payment gateways.', 'Web Development', 1000, 'Active');

INSERT INTO Services (serviceID, userID, name, description, category, basePrice, status)
VALUES (3, 3, 'Single Page Application (SPA) Development', 'Build dynamic and interactive web applications.', 'Web Development', 1800, 'Active');

INSERT INTO Services (serviceID, userID, name, description, category, basePrice, status)
VALUES (4, 4, 'E-commerce Platform Integration', 'Integrate your e-commerce store with popular platforms.', 'Web Development', 700, 'Active');





-------- Achievement Table ---------------

CREATE TABLE Achievements (
    achievementID  INT PRIMARY KEY,           -- Unique identifier for the achievement
    userID         INT NOT NULL,              -- Foreign key linking to User table
    title          VARCHAR2(100) NOT NULL,    -- Title of the achievement
    description  CLOB NOT NULL,              -- Foreign key linking to a descriptions table
    achievementDate TIMESTAMP NOT NULL          -- Date of the achievement

) TABLESPACE USERS;

INSERT INTO Achievements (achievementID, userID, title, description, achievementDate)
VALUES (1, 1, 'Completed First Project', 'Successfully completed the first web development project.', TIMESTAMP '2023-11-21 00:00:00');

INSERT INTO Achievements (achievementID, userID, title, description, achievementDate)
VALUES (2, 1, 'Achieved 1000 Followers', 'Gained 1000 followers on social media platforms.', TIMESTAMP '2023-12-15 00:00:00');

INSERT INTO Achievements (achievementID, userID, title, description, achievementDate)
VALUES (3, 1, 'Secured First Client', 'Landed the first major client for the startup.', TIMESTAMP '2024-01-10 00:00:00');

INSERT INTO Achievements (achievementID, userID, title, description, achievementDate)
VALUES (4, 1, 'Raised Seed Funding', 'Successfully raised seed funding for the startup.', TIMESTAMP '2024-03-20 00:00:00');

INSERT INTO Achievements (achievementID, userID, title, description, achievementDate)
VALUES (5, 3, 'Completed First Product Launch', 'Successfully launched the first product to the market.', TIMESTAMP '2024-04-15 00:00:00');

select * from Achievements ;

delete from Achievements ; 

drop table Achievements ;


-------- MEetings Table --------

CREATE TABLE Meetings (
    meetingID INT PRIMARY KEY,             -- Unique identifier for the meeting
    userAID   INT NOT NULL,                -- Foreign key linking to User table (user A)
    userBID   INT NOT NULL,                -- Foreign key linking to User table (user B)
    timeSlot  TIMESTAMP NOT NULL,          -- Timestamp for the meeting schedule
    status    VARCHAR2(50) CHECK (status IN ('Scheduled', 'Completed', 'Cancelled'))
    
) TABLESPACE USERS;

INSERT INTO Meetings (meetingID, userAID, userBID, timeSlot, status)
VALUES (1, 1, 2, TIMESTAMP '2023-11-28 10:00:00', 'Scheduled');

INSERT INTO Meetings (meetingID, userAID, userBID, timeSlot, status)
VALUES (2, 1, 2, TIMESTAMP '2023-12-02 14:00:00', 'Scheduled');

INSERT INTO Meetings (meetingID, userAID, userBID, timeSlot, status)
VALUES (3, 2, 1, TIMESTAMP '2023-12-05 09:30:00', 'Scheduled');

INSERT INTO Meetings (meetingID, userAID, userBID, timeSlot, status)
VALUES (4, 2, 1, TIMESTAMP '2023-12-10 16:15:00', 'Scheduled');

select * from Meetings ;

delete from Meetings ;



----- Notifications Table -------

CREATE TABLE Notifications (
    notificationID INT PRIMARY KEY,                     -- Unique identifier for the notification
    userID         INT NOT NULL,                        -- Foreign key linking to Users table
    message        VARCHAR2(255) NOT NULL,              -- Message content of the notification
    timeStamp       TIMESTAMP NOT NULL,                 -- Time of the notification
    readStatus     VARCHAR2(10) CHECK (readStatus IN ('read', 'unread')), -- Read status
    type           VARCHAR2(500)                        -- Type of notification (e.g., Msg, Announcement)
) TABLESPACE USERS;


select * from Notifications ; 

delete from Notifications ; 

