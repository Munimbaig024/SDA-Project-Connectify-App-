module org.example.myjavafxapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
//    requires mysql.connector.java;

    requires com.dlsc.formsfx;
    requires java.desktop;

    opens org.example.myjavafxapp;
    exports org.example.myjavafxapp;
}