package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class BiggerCompany extends User {

    private String industry;
    private int teamSize; // This can be an estimate
    private List<Job> jobs; // List of jobs announced by the startup

    // Constructor - for creating a new USer
    public BiggerCompany(String name, String email, String password, String industry, int teamSize) {
        super( name, email, password); // Calls the constructor of the User class
        this.industry = industry;
        this.teamSize = teamSize;
        this.jobs = new ArrayList<>(); // Initializes the job array
    }

    // Constructor - loading from DB
    public BiggerCompany(int userID, String name, String email, String password, Date createdAt, String industry, int teamSize) {
        super(userID, name, email, password, createdAt); // Calls the constructor of the User class
        this.industry = industry;
        this.teamSize = teamSize;
        this.jobs = new ArrayList<>(); // Initializes the job array
    }

    // Method to announce a job
    public void announceJob(String title, String description, String category, String location, String status) {
        Job newJob = new Job(this.userID, title, description, category,  status);
        jobs.add(newJob);
        System.out.println("Job announced successfully: " + title);
    }


    // this will be called from Database.
    public void addJob  (Job job ) {
        jobs.add(job);
    }

    // Getters and Setters

    @Override
    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    @Override
    public int getTeamSize() {
        return teamSize;
    }

    public void setTeamSize(int teamSize) {
        this.teamSize = teamSize;
    }

    public List<Job> getJobs() {
        return jobs;
    }

    public void setJobs(ArrayList<Job> jobs) {
        this.jobs = jobs;
    }

}
