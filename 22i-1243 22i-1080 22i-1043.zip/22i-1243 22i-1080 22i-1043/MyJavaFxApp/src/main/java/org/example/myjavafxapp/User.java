package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public abstract class User {
    protected int userID;
    protected String name;
    protected String email;
    protected String password;
    protected Date createdAt;
    protected List<Notification> notifications;



    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }


    // Constructor - for creating a new user
    public User(  String name, String email, String password) {
        this.userID = generateUniqueID() ;
        this.name = name;
        this.email = email;
        this.password = password;
        this.createdAt = new Date(); // Sets creation time to the current date
        this.notifications = new ArrayList<>(); // Initializes the notification array
    }

    // Constructor - loading from DB
    public User(int userID, String name, String email, String password, Date createdAt) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.createdAt = createdAt;
        this.notifications = new ArrayList<>(); // Initializes the notification array

        generateUniqueID () ;
    }

    // Method to receive a notification
    public void receiveNotification(Notification notification) {
        this.notifications.add(notification);
        System.out.println("Notification received: " + notification.getMessage());
    }

    // Getters and Setters
    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }

    abstract public String getIndustry() ;

    abstract public int getTeamSize() ;


}

