package org.example.myjavafxapp;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import org.w3c.dom.events.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {

    @FXML
    private Button viewProfileButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Label choiceBoxLabel;

    @FXML
    private ChoiceBox<String> userChoiceBox;
    private String[] users = {"StartUp", "Company"};

    @FXML
    public void cancelButtonOnAction(ActionEvent event) {
        loadFXML("login.fxml", 600, 405);
        // Close the current stage
        Stage currentStage = (Stage) cancelButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    private Button registerButton;

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }

    @FXML
    public void registerButtonOnAction(ActionEvent event) {
        // Add into DB
        // depending on Start up or Established Companies open that menu
        loadFXML("startupMenu.fxml", 872, 586);
        // Close the current stage
        Stage currentStage = (Stage) registerButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        userChoiceBox.getItems().addAll(users);
        userChoiceBox.setOnAction(this::getUser);
    }

    public void getUser(ActionEvent event)
    {
        String selectedUser = userChoiceBox.getValue();
        String welcomeMessage = "Welcome " + selectedUser + "!";
        choiceBoxLabel.setText(welcomeMessage);
    }
}
