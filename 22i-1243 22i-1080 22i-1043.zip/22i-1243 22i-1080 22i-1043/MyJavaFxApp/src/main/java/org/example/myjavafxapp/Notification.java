package org.example.myjavafxapp;

import java.util.Date;

public class Notification {
    private int notificationID;
    private int userID;
    private String message;
    private Date timeStamp;
    private String readStatus; // Can be "read" or "unread"
    private String type; // Notification type, Msg , Announcement etc


    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }


    // Constructor - for creating a new notification
    public Notification(int userID, String message, String type) {
        this.notificationID = generateUniqueID();
        this.userID = userID;
        this.message = message;
        this.timeStamp = new Date(); // Sets the time stamp to the current date/time
        this.readStatus = "unread"; // Default status
        this.type = type;
    }

    // Constructor - loading from DB
    public Notification(int notificationID, int userID, String message, Date timeStamp, String readStatus, String type) {
        this.notificationID = notificationID;
        this.userID = userID;
        this.message = message;
        this.timeStamp = timeStamp;
        this.readStatus = readStatus;
        this.type = type;
        generateUniqueID(); // If needed, validate or regenerate ID here
    }


    public void NotificationRead () {
        this.readStatus = "read";
        DBHandler.getInstance().updateNotificationStatus (this.getNotificationID());
    }



    // Method to add or update a notification
    public void addNotification(String message, String type) {
        this.message = message;
        this.type = type;
        this.timeStamp = new Date(); // Updates the timestamp to the current date/time
        this.readStatus = "unread"; // Resets status to unread
    }

    // Getters and Setters
    public int getNotificationID() {
        return notificationID;
    }

    public void setNotificationID(int notificationID) {
        this.notificationID = notificationID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getReadStatus() {
        return readStatus;
    }

    public void setReadStatus(String readStatus) {
        this.readStatus = readStatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
