package org.example.myjavafxapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;


public class SetupEventController implements Initializable {

    @FXML
    private Label CompanyTitle;

    @FXML
    private Button JobButton;

    @FXML
    private Label StartupDashboardTitle;

    @FXML
    private Label StartupDashboardTitle1;

    @FXML
    private Button chatButton;

    @FXML
    private ImageView companyImageField;

    @FXML
    private DatePicker enterDate;

    @FXML
    private TextArea enterDescription;

    @FXML
    private TextField enterLocation;

    @FXML
    private TextField enterName;

    @FXML
    private Button eventbutton;

    @FXML
    private Button logOutButton;

    @FXML
    private Button meetingButton;

    @FXML
    private Button notificationButton;

    @FXML
    private Button saveButton;

    @FXML
    private Button similarStartupButton;

    @FXML
    private Button viewButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Perform initialization tasks
        System.out.println("Controller initialized");
    }

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }


    @FXML
    void SaveButtonOnAction(ActionEvent event) {
        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        String date = Connectify.getInstance().ConvertIntoString(enterDate.getValue());
        java.util.Date updateddate = Connectify.getInstance().processDateTime(date, "12:00:00");
        Connectify.getInstance().addEvent(user, enterName.getText(), enterDescription.getText(), updateddate, enterLocation.getText());

        enterDate.setValue(null);
        enterDescription.clear();
        enterLocation.clear();
        enterName.clear();
    }

    @FXML
    public void NotificationButtonOnAction(ActionEvent event) {
        loadFXML("notificationCompany.fxml", 872, 586);

        Stage currentStage = (Stage) notificationButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void SimilarStartupButtonOnAction(ActionEvent event) {
        loadFXML("findSimilarStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) similarStartupButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void MeetingButtonOnAction(ActionEvent event)
    {
        loadFXML("scheduleMeetingCompany.fxml", 872, 586);
        Stage currentStage = (Stage) meetingButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ChatButtonOnAction(ActionEvent event)
    {
        loadFXML("ChatStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) chatButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void LogOutButtonOnAction(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), 600, 405);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();

            // Close the current stage
            Stage currentStage = (Stage) logOutButton.getScene().getWindow();
            // Apply fade-out transition to the current scene
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);

            // Set an action on fade transition completion
            fadeOut.setOnFinished(e -> currentStage.close());

            // Start the fade-out transition
            fadeOut.play();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Logout Error");
            alert.setContentText("Unable to logout and switch to the login screen.");
            alert.showAndWait();
        }
    }

    @FXML
    void EventButtonOnAction(ActionEvent event) {
        loadFXML("setupEvent.fxml", 872, 586);
        Stage currentStage = (Stage) eventbutton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void JobButtonOnAction(ActionEvent event) {
        loadFXML("announceJobCompany.fxml", 872, 586);
        Stage currentStage = (Stage) JobButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void ViewButtonOnAction(ActionEvent event) {
        loadFXML("viewProfileCompany.fxml", 872, 586);
        Stage currentStage = (Stage) viewButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }
}

