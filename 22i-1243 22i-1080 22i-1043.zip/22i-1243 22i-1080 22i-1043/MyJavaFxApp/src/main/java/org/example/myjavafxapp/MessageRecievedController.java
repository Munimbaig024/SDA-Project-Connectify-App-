package org.example.myjavafxapp;

public class MessageRecievedController {
}
