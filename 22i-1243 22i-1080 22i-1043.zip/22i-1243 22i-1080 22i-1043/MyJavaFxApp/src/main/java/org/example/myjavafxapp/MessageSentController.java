package org.example.myjavafxapp;

public class MessageSentController {
}
