package org.example.myjavafxapp;

import java.net.URL;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class ChatStartupCompany implements Initializable {

    @FXML
    private Label CompanyTitle;

    @FXML
    private Button JobButton;

    @FXML
    private Label StartupDashboardTitle;

    @FXML
    private Label StartupDashboardTitle1;

    @FXML
    private Button chatButton;

    @FXML
    private ImageView companyImageField;

    @FXML
    private TextField emailTextField;

    @FXML
    private TextField enterMessage;

    @FXML
    private Button eventbutton;

    @FXML
    private Button logOutButton;

    @FXML
    private Button meetingButton;

    @FXML
    private Button notificationButton;

    @FXML
    private Button similarStartupButton;

    @FXML
    private GridPane messagePanel;

    @FXML
    private Button submitButton;

    @FXML
    private Button viewButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        emailTextField.setOnAction(event -> updateShortlistStartups());
        submitButton.setOnAction(event -> SubmitButtonOnAction());
    }

    public void updateShortlistStartups() {
        // Get current user (userA) and retrieve users list
        User userA = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<User> users = Connectify.getInstance().getUsers();

        // Find userB based on email in emailTextField
        User userB = null;
        for (User user : users) {
            if (Objects.equals(user.getEmail(), emailTextField.getText())) {
                userB = user;
                break;
            }
        }

        // Ensure userB exists
        if (userB == null) {
            showAlert("User not found.", Alert.AlertType.WARNING);
            return;
        }

        // Get the conversation between userA and userB
        Conversation conversation = Connectify.getInstance().getConversation(userA.getUserID(), userB.getUserID());

        // Check if conversation exists
        if (conversation == null) {
            showAlert("No conversation found between users.", Alert.AlertType.WARNING);
            return;
        }

        // Clear previous components in messagePanel
        messagePanel.getChildren().clear();

        // Iterate through the messages in the conversation
        int row = 0;
        for (Message message : conversation.getMessages()) {
            Label label;

            if (Objects.equals(message.getSenderID(), userA.getUserID())) {
                // Message sent by userA
                label = createStyledLabel("Your Message: " + message.getText(), Color.GREEN);
            } else if (Objects.equals(message.getSenderID(), userB.getUserID())) {
                // Message sent by userB
                label = createStyledLabel("Message Sent: " + message.getText(), Color.ORANGE);
            } else {
                continue; // Skip messages from unknown users
            }

            // Add the label to the messagePanel at the correct row
            messagePanel.add(label, 0, row++);
        }
    }

    /**
     * Creates a styled label with a specific text and background color.
     *
     * @param text  The text for the label.
     * @param color The background color of the label.
     * @return A styled Label instance.
     */
    private Label createStyledLabel(String text, Color color) {
        Label label = new Label(text);
        label.setBackground(new Background(new BackgroundFill(color, CornerRadii.EMPTY, Insets.EMPTY)));
        label.setPadding(new Insets(5));
        label.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        return label;
    }

    @FXML
    public void SubmitButtonOnAction(){
        User myuser = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<User> users = Connectify.getInstance().getUsers();

        // Find userB based on email in emailTextField
        User userB = null;
        for (User user : users) {
            if (Objects.equals(user.getEmail(), emailTextField.getText())) {
                userB = user;
                break;
            }
        }
        Connectify.getInstance().send_a_message(myuser, userB.getUserID(), enterMessage.getText());
        updateShortlistStartups();
        String message = myuser.getName() + ": \"" + enterMessage.getText() + "\"";
        Connectify.getInstance().addNotification(userB.getUserID(), message, "Message");
    }

    /**
     * Shows an alert dialog with a specific message and alert type.
     *
     * @param message    The message to display.
     * @param alertType The type of alert to show.
     */
    private void showAlert(String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(alertType == Alert.AlertType.WARNING ? "Warning" : "Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }

    @FXML
    public void NotificationButtonOnAction(ActionEvent event) {
        loadFXML("notificationCompany.fxml", 872, 586);

        Stage currentStage = (Stage) notificationButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void SimilarStartupButtonOnAction(ActionEvent event) {
        loadFXML("findSimilarStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) similarStartupButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void MeetingButtonOnAction(ActionEvent event)
    {
        loadFXML("scheduleMeetingCompany.fxml", 872, 586);
        Stage currentStage = (Stage) meetingButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ChatButtonOnAction(ActionEvent event)
    {
        loadFXML("ChatStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) chatButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void LogOutButtonOnAction(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), 600, 405);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();

            // Close the current stage
            Stage currentStage = (Stage) logOutButton.getScene().getWindow();
            // Apply fade-out transition to the current scene
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);

            // Set an action on fade transition completion
            fadeOut.setOnFinished(e -> currentStage.close());

            // Start the fade-out transition
            fadeOut.play();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Logout Error");
            alert.setContentText("Unable to logout and switch to the login screen.");
            alert.showAndWait();
        }
    }

    @FXML
    void EventButtonOnAction(ActionEvent event) {
        loadFXML("setupEvent.fxml", 872, 586);
        Stage currentStage = (Stage) eventbutton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void JobButtonOnAction(ActionEvent event) {
        loadFXML("announceJobCompany.fxml", 872, 586);
        Stage currentStage = (Stage) JobButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void ViewButtonOnAction(ActionEvent event) {
        loadFXML("viewProfileCompany.fxml", 872, 586);
        Stage currentStage = (Stage) viewButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }
}

