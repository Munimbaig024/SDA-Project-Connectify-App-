package org.example.myjavafxapp;

import java.util.Date;

public class JobApplication {
    private int applicantID;
    private int jobID;
    private int startupID; // basically user ID
    private String coverLetter;
    private Date submittedDate;
    private boolean status; // true for accepted, false for pending/rejected


    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }

    // Constructor - for creating a new job application
    public JobApplication ( int jobID, int startupID, String coverLetter) {
        this.applicantID = generateUniqueID();
        this.jobID = jobID;
        this.startupID = startupID;
        this.coverLetter = coverLetter;
        this.submittedDate = new Date(); // Sets the submitted date to the current date
        this.status = false; // Default status is pending
    }

    // Constructor - loading from DB
    public JobApplication (int applicantID, int jobID, int startupID, String coverLetter, Date submittedDate, boolean status) {
        this.applicantID = applicantID;
        this.jobID = jobID;
        this.startupID = startupID;
        this.coverLetter = coverLetter;
        this.submittedDate = submittedDate;
        this.status = status;
        generateUniqueID () ;
    }

    // Method to add or update a job application
    public void addApplication(int applicantID, int jobID, int startupID, String coverLetter) {
        this.applicantID = applicantID;
        this.jobID = jobID;
        this.startupID = startupID;
        this.coverLetter = coverLetter;
        this.submittedDate = new Date(); // Updates the submitted date to the current date
        this.status = false; // Resets status to pending
    }

    public void acceptApplication () {
        this.status = true;
        DBHandler.getInstance().updateApplicationStatus(this.applicantID);

    }


    // Getters and Setters
    public int getApplicantID() {
        return applicantID;
    }

    public void setApplicantID(int applicantID) {
        this.applicantID = applicantID;
    }

    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public int getStartupID() {
        return startupID;
    }

    public void setStartupID(int startupID) {
        this.startupID = startupID;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public Date getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(Date submittedDate) {
        this.submittedDate = submittedDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
