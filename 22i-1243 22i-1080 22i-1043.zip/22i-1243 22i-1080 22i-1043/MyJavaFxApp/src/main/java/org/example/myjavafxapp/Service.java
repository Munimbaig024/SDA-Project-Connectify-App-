package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.Date;

public class Service {


    private int serviceID;
    private int userID;
    private String name;
    private String description;
    private String category;
    private int basePrice;
    private String status;


    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }



    // Constructor - for creating a new service
    public Service(int userID, String name, String description, String category, int basePrice ) {
        this.serviceID = generateUniqueID();
        this.userID = userID;
        this.name = name;
        this.description = description;
        this.category = category;
        this.basePrice = basePrice;
        this.status = "Active";

    }

    // Constructor - loading from DB
    public Service(int serviceID, int userID, String name, String description, String category, int basePrice, String status ) {
        this.serviceID = serviceID;
        this.userID = userID;
        this.name = name;
        this.description = description;
        this.category = category;
        this.basePrice = basePrice;
        this.status = status;

        generateUniqueID(); // If needed, validate or regenerate ID here
    }



    // Method to enter or update service details
    public void enterDetails(String name, String description, String category, int basePrice, String status) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.basePrice = basePrice;
        this.status = status;
    }

    // Method to find services by category, will further implement this in user class: start up
    public static ArrayList<Service> findServices(ArrayList<Service> services, String category) {
        ArrayList<Service> matchedServices = new ArrayList<>();
        for (Service service : services) {
            if (service.getCategory().equalsIgnoreCase(category)) {
                matchedServices.add(service);
            }
        }
        return matchedServices;
    }

    // Getters and Setters
    public int getServiceID() {
        return serviceID;
    }

    public void setServiceID(int serviceID) {
        this.serviceID = serviceID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(int basePrice) {
        this.basePrice = basePrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
