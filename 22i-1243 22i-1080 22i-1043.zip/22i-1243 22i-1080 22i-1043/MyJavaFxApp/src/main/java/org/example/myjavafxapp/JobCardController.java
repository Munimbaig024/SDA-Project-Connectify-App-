package org.example.myjavafxapp;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class JobCardController {
    @FXML
    private Button applyButton;

    @FXML
    private TextArea setDescription;

    @FXML
    private Label setName;

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }

    @FXML
    void ApplyButtonOnAction(ActionEvent event) {
        loadFXML("applyForJob.fxml", 872, 586);

        Stage currentStage = (Stage) applyButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    public void setData(Job job) {
        setName.setText(job.getTitle());
        setDescription.setText(job.getDescription());
    }
}
