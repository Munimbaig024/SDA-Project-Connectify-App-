package org.example.myjavafxapp;

import java.util.Date;

public class Events {
    // Attributes
    private int eventID;       // Unique identifier for the event
    private int userID;        // ID of the user creating the event : foreign
    private String name;       // Name of the event
    private String description;// Description of the event
    private Date date;         // Date of the event
    private String location;   // Location of the event

    // Static variable to keep track of unique Event IDs
    private static int eventCounter = 0;


    // Constructor

    public Events () {}

    public Events( int userID, String name, String description, Date date, String location) {
        this.eventID = generateUniqueEventID() ;
        this.userID = userID;
        this.name = name;
        this.description = description;
        this.date = date;
        this.location = location;
    }

    // for loading from DB
    public Events(int eventID, int userID, String name, String description, Date date, String location) {
        this.eventID = eventID;
        this.userID = userID;
        this.name = name;
        this.description = description;
        this.date = date;
        this.location = location;
        generateUniqueEventID() ; // when reloading data from DB , still need to keep count.
    }

    // Static method to generate unique conversation ID
    private static int generateUniqueEventID() {
        return ++eventCounter;
    }


    // Getters and Setters
    public int getEventID() {
        return eventID;
    }

    public void setEventID(int eventID) {
        this.eventID = eventID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    // Method to display event details
    public void displayEvent() {
        System.out.println("Event ID: " + eventID);
        System.out.println("User ID: " + userID);
        System.out.println("Name: " + name);
        System.out.println("Description: " + description);
        System.out.println("Date: " + date);
        System.out.println("Location: " + location);
    }
}



//// some code that will help me later :
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//public class Main {
//    public static void main(String[] args) throws Exception {
//        // Example date and time in string format
//        String dateTimeString = "2024-11-10 14:30:00";
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//
//        // Parse the string into a Date object
//        Date date = formatter.parse(dateTimeString);
//
//        // Display the date and time
//        System.out.println("Date and Time: " + date);
//    }
//}

