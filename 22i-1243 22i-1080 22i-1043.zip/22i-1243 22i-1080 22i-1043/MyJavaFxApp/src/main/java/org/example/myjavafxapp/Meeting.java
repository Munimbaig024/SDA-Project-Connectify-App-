package org.example.myjavafxapp;
import java.util.Date;

public class Meeting {

    private int meetingID;
    private int userAID;
    private int userBID;

    private Date timeSlot; // Updated to Date to include both date and time
    private String status; // : "Scheduled", "Completed", "Cancelled"


    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }



    // Constructor - for scheduling a new meeting
    public Meeting(int userAID, int userBID, Date timeSlot, String status ) {
        this.meetingID = generateUniqueID();
        this.userAID = userAID;
        this.userBID = userBID;
        this.timeSlot = timeSlot;
        this.status = status;

    }



    // Constructor - loading from DB
    public Meeting(int meetingID, int userAID, int userBID, Date timeSlot, String status) {
        this.meetingID = meetingID;
        this.userAID = userAID;
        this.userBID = userBID;
        this.timeSlot = timeSlot;
        this.status = status;
        generateUniqueID () ;
    }



    // Method to schedule a meeting
    public void scheduleMeeting(int userAID, int userBID, Date timeSlot) {
        this.userAID = userAID;
        this.userBID = userBID;
        this.timeSlot = timeSlot;
        this.status = "Scheduled"; // Default status when scheduling a meeting
        System.out.println("Meeting scheduled successfully between User " + userAID + " and User " + userBID + " at " + timeSlot);
    }

    public void update_Status(String status) {
        this.status = status;
        DBHandler.getInstance().updateMeetingStatus(this.meetingID , status );

    }

    // Getters and Setters
    public int getMeetingID() {
        return meetingID;
    }

    public void setMeetingID(int meetingID) {
        this.meetingID = meetingID;
    }

    public int getUserAID() {
        return userAID;
    }

    public void setUserAID(int userAID) {
        this.userAID = userAID;
    }

    public int getUserBID() {
        return userBID;
    }

    public void setUserBID(int userBID) {
        this.userBID = userBID;
    }

    public Date getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(Date timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
