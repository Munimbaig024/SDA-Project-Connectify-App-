package org.example.myjavafxapp;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.scene.control.TextField;

import java.util.ArrayList;
import java.util.List;

public class LoginController {
//    @FXML
//    private Label welcomeText;
//
//    @FXML
//    protected void onHelloButtonClick() {
//        welcomeText.setText("Welcome to JavaFX Application!");
//    }

    @FXML
    private TextField enterPasswordField;

    @FXML
    private TextField usernameTextField;

    @FXML
    private Button cancelButton;

    @FXML
    public void cancelButtonOnAction(ActionEvent event) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private Button loginButton;

    @FXML
    public void loginButtonOnAction(ActionEvent event) {
        // validation through DB
        this.RegisterAccount();
    }

    @FXML
    public void RegisterAccount()
    {
        try {
//            DBHandler.getInstance().addMeeting(newMeeting);

            User user = Connectify.getInstance().getUserByCredentials(usernameTextField.getText(), enterPasswordField.getText());
            System.out.println(usernameTextField.getText());
            System.out.println(enterPasswordField.getText());



            if (user == null) {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("register.fxml"));
                Stage registerstage = new Stage();
                registerstage.initStyle(StageStyle.UNDECORATED);
                // Load the FXML and set the Scene
                Scene scene = new Scene(fxmlLoader.load(), 600, 405);
                registerstage.setScene(scene);
                // Apply Fade Transition
                TransitionHelper.applyFadeTransition(scene.getRoot());
                // Show the Stage
                registerstage.show();
            }
            else if(user.getClass() == Startup.class) {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("startupMenu.fxml"));
                Stage registerstage = new Stage();
                registerstage.initStyle(StageStyle.UNDECORATED);
                // Load the FXML and set the Scene
                Scene scene = new Scene(fxmlLoader.load(), 872, 586);
                registerstage.setScene(scene);
                // Apply Fade Transition
                TransitionHelper.applyFadeTransition(scene.getRoot());
                // Show the Stage
                registerstage.show();
            }
            else if(user.getClass() == BiggerCompany.class) {
//                User myuser = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
//                BiggerCompany newUser = (BiggerCompany) myuser;
//
//                for (Job job : newUser.getJobs() ) {
//                    System.out.println(job.getTitle());
//                }
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("companyMenu.fxml"));
                Stage registerstage = new Stage();
                registerstage.initStyle(StageStyle.UNDECORATED);
                // Load the FXML and set the Scene
                Scene scene = new Scene(fxmlLoader.load(), 872, 586);
                registerstage.setScene(scene);
                // Apply Fade Transition
                TransitionHelper.applyFadeTransition(scene.getRoot());
                // Show the Stage
                registerstage.show();
            }

            // Close the current stage
            Stage currentStage = (Stage) loginButton.getScene().getWindow();
            // Apply fade-out transition to the current scene
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);

            // Set an action on fade transition completion
            fadeOut.setOnFinished(e -> currentStage.close());

            // Start the fade-out transition
            fadeOut.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}