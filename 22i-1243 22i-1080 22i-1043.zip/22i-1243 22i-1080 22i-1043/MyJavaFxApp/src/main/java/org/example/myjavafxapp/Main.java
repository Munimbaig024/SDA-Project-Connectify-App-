package org.example.myjavafxapp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Main {

//
//    public static void main (String[] args) {
//
//        Date date = new Date(); // Example date, replace with your actual date
////        System.out.println(date);
//        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//
//        int year = localDate.getYear();
//        int month = localDate.getMonthValue(); // Months are 1-based here
//
//        System.out.println("Year: " + year);
//        System.out.println("Month: " + month);
//
//
//
//
////
////
////        Connectify connect = new Connectify();
////
////        connect.printAllUsers();
////        User u = connect.getUser(1);
////        if (u.getClass() == Startup.class) {
////            System.out.println("Welcome to the Startup!");
////            Startup startup = (Startup) u;
////
////           int [] y=  connect.getFinancialData (2024 , startup);
////           for ( int show : y ) {
////               System.out.println(show);
////
////           }
////
////        }
//
//
//
//    }
//

//
//    public static void main (String [] args ){
//        // Example list to store notifications
//        List<Notification> notifications = new ArrayList<>();

//// Load notifications into the list
//
//        DBHandler.getInstance() .loadNotifications(notifications);
//
//// Print loaded notifications
//        for (Notification notification : notifications) {
//            System.out.println("Notification ID: " + notification.getNotificationID());
//            System.out.println("Message: " + notification.getMessage());
//            System.out.println("Status: " + notification.getReadStatus());
//            System.out.println("Type: " + notification.getType());
//        }
//
//        try {
//            String dateString = "25-11-2024 11:00:00";
//            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//            Date date = dateFormat.parse(dateString);
//            Meeting n = new Meeting( 1, 2,  date , "Scheduled"  );
//            DBHandler.getInstance() .addMeeting(n);
////            System.out.println("Parsed Date: " + date);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }


//
//        // Example list to store meetings
//        List<Meeting> meetings = new ArrayList<>();
//
//// Load meetings into the list
//
//        DBHandler.getInstance().loadMeetings(meetings);
//
//// Print loaded meetings
//        for (Meeting meeting : meetings) {
//            System.out.println("Meeting ID: " + meeting.getMeetingID());
//            System.out.println("User A ID: " + meeting.getUserAID());
//            System.out.println("User B ID: " + meeting.getUserBID());
//            System.out.println("Time Slot: " + meeting.getTimeSlot());
//            System.out.println("Status: " + meeting.getStatus());
//        }



//    }

//
//public static void main(String[] args) {
//
//    // Example FinancialData object
//    FinancialData financialData = new FinancialData(1 ) ;
//
//// Add financial data to the database
//
//    DBHandler.getInstance().AddFinancialData(financialData);
//
//
//
//// Example FinancialEntry object
//    FinancialEntry entry = new FinancialEntry( 1, 2000, 5000 , new Date () );
//
//// Add financial entry to the database
//    DBHandler.getInstance().AddFinancialEntry(entry);
//
////    // Example Goals object
////    Goals goal = new Goals(1,"Save up for pokemon cards" , new Date() );
////    goal.setFinancialGoal(100000);
////
////// Add goal to the database
////    DBHandler.getInstance().addGoal(goal);
//
//
////    // Example Service object
////    Service service = new Service(1, "Web Development" , "Frontend and backend: Node JS , React" , "Coding" , 500  );
////
////     // Add service to the database.
////    DBHandler.getInstance().addService( service );
//
////    // Example Achievement object.
////    Achievement achievement = new Achievement(1 , "Award winning" , "We won a Hackathon 2021" , new Date() );
////
////    // Add achievement to the database.
////    DBHandler.getInstance().addAchievement(achievement) ;
//
//
////    // Example Notification object.
////    Notification notification = new Notification(1 , "Welcome to Connectify!" , "Greeting" ) ;
////
////    // Add notification to the database.
////    DBHandler.getInstance().addNotification(notification) ;
//
////    Date date = new Date(); // Example date, replace with your actual date
////    LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
////
////    int year = localDate.getYear();
////    int month = localDate.getMonthValue(); // Months are 1-based here
////
////    System.out.println("Year: " + year);
////    System.out.println("Month: " + month);
//
//}




//// load a user (Bigger company with jobs )
    public  static void main(String[] args) throws ParseException {

     List <User> users = new ArrayList<>() ;
     DBHandler.getInstance().LoadUsers (users) ;

     System.out.println ("------------------ To check Data Loading ------------------------" );

     for (User u : users) {
         System.out.println("Name of Company: " + u.getName());
         if ( u.getClass() == BiggerCompany.class) {
             System.out.println("Jobs Posted: ");
             BiggerCompany b = (BiggerCompany) u ;
             List <Job > jobs =  b.getJobs() ;
             int i =1 ;
             for (Job j : jobs) {
               System.out.println( i + ". " + j.getTitle() );
                i++ ;
             }

         }
         // start ups
         else {
             Startup temp = (Startup) u ;
//             FinancialData temp2 = temp.getFinancialData();
//             temp2.generateReport();

//             List<Service> s = temp.getServices();
//             for (Service s2 : s ) {
//                  String print = s2.getName();
//                  System.out.println( print );
//
//             }

//             List <Goals> g = temp.getGoals() ;
//             for (Goals g1 : g) {
//                 String print = g1.getDescription() ;
//                 System.out.println( "Goal: " + print );
//             }

             List <Achievement> achievements =  temp.getAchievements() ;
             for ( Achievement a : achievements)
             {
                 System.out.println ( "Achievement : " +  a.getTitle() );

             }

         }
         System.out.println("-------------------------------------" );

     }




    }


//     add an application for Job :
//
//    public static void main(String[] args) {
//
//        DBHandler dbHandler = DBHandler.getInstance();
//
//        // Example job application, startupId Means user Id
//        JobApplication application1 = new JobApplication(
//                 1, 3, "Umm i think...   blah blah blah plus you are gay!"
//        );
//        dbHandler.addJobApplication(application1);
//
//        JobApplication application2 = new JobApplication(
//                2, 4, "My skills align perfectly with the job requirements."
//        );
//        dbHandler.addJobApplication(application2);
//    }



//
//    /// add a job
//    public static void main(String[] args) {
//        DBHandler dbHandler = DBHandler.getInstance();
//
//        // Example job for a user
//        Job job1 = new Job( 1, "Software Developer", "Develop cutting-edge software solutions.", "IT", "Open");
//        dbHandler.addJob(job1);
//
//        Job job2 = new Job( 1, "Marketing Specialist", "Develop marketing campaigns for new products.", "Marketing", "Open");
//        dbHandler.addJob(job2);
//
//    }


    //// Add a user
//    public static void main(String[] args) {
//
//
//        User s1 = new Startup(
//
//                "Tech Innovators",       // name
//                "contact@techinnovators.com", // email
//                "securePass123",         // password
//                "Technology",            // industry
//                10                       // teamSize
//        );
//
//        User s2 = new BiggerCompany(
//
//                "Global Enterprises",    // name
//                "info@globalenterprises.com", // email
//                "globalSecure456",       // password
//                "Finance",               // industry
//                250                      // teamSize
//        );
//
//        System.out.println( s1.getUserID() );
//        System.out.println( s2.getUserID() );
//
//
//        List <User> users = new ArrayList<>();
//        users.add(s1);
//        users.add(s2);
//
//        DBHandler db = new DBHandler();
//        db.addUser(s1, "Startup");
//        db.addUser(s2, "BiggerCompany");
//
//
//
//        for (User u : users ) {
//            System.out.println( u.getName() );
//        }
//
//
//
//
//
//    }

    // to load events
//    public static void main(String[] args) {
//
//        DBHandler dbHandler = new DBHandler();
//        List<Events> events = new ArrayList<>();
//
//        dbHandler.LoadEvents(events );
//
//        System.out.println("Loaded Events:");
//        for (Events event : events) {
//            System.out.println("Event ID: " + event.getEventID());
//            System.out.println("User ID: " + event.getUserID());
//            System.out.println("Name: " + event.getName());
//            System.out.println("Description: " + event.getDescription());
//            System.out.println("Date: " + event.getDate());
//            System.out.println("Location: " + event.getLocation());
//            System.out.println("-----------------------------------");
//        }
//    }
//


    // To Add a event

//    public static void main(String[] args) {

//        Scanner scanner = new Scanner(System.in);
//        DBHandler dbHandler = new DBHandler();
//
//        System.out.print("Enter the number of events: ");
//        int numOfEvents = scanner.nextInt();
//        scanner.nextLine(); // Consume newline
//
//        // Create an array of Events
//        Events[] eventsArray = new Events[numOfEvents];
//
//        for (int i = 0; i < numOfEvents; i++) {
//            System.out.println("\nEnter details for Event " + (i + 1) + ":");
//
//            // Create a new Events object
//            Events event = new Events();
//
//            // Input event details
//            System.out.print("Event ID: ");
//            event.setEventID(scanner.nextInt());
//            scanner.nextLine(); // Consume newline
//
//            System.out.print("User ID: ");
//            event.setUserID(scanner.nextInt());
//            scanner.nextLine(); // Consume newline
//
//            System.out.print("Name: ");
//            event.setName(scanner.nextLine());
//
//            System.out.print("Description: ");
//            event.setDescription(scanner.nextLine());
//
//            System.out.print("Date and Time (yyyy-MM-dd HH:mm:ss): ");
//            String dateInput = scanner.nextLine();
//
//            try {
//                // Parse the string into a Date object
//                Date eventDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateInput);
//                event.setDate(eventDate);
//            } catch (ParseException e) {
//                System.out.println("Invalid date format. Skipping this event.");
//                continue;
//            }
//
//            System.out.print("Location: ");
//            event.setLocation(scanner.nextLine());
//
//            // Add the event to the array
//            eventsArray[i] = event;
//        }
//
//        // Add all events to the database
//        for (Events event : eventsArray) {
//            if (event != null) {
//                dbHandler.addEvent(event);
//            }
//        }
//
//        System.out.println("\nAll events have been processed.");
//        scanner.close();
//    }
//



//
////  CHat Box
//
//    public static  void main(String[] args) {
//
//        DBHandler db = DBHandler.getInstance();
//
//
//        ChatBox chatBox = new ChatBox();
//        Scanner scanner = new Scanner(System.in);
//        db.LoadConversation(chatBox) ;
//
//        int userAID = 0;
//        int userBID = 0;
//
//        // Input validation for userAID and userBID
//        while (true) {
//            try {
//                System.out.print("Enter User A ID: ");
//                userAID = Integer.parseInt(scanner.nextLine().trim());
//
//                System.out.print("Enter User B ID (different from User A): ");
//                userBID = Integer.parseInt(scanner.nextLine().trim());
//
//                if (userAID != userBID) {
//                    break;
//                } else {
//                    System.out.println("User B ID should be different from User A ID. Please try again.");
//                }
//            } catch (NumberFormatException e) {
//                System.out.println("Invalid input. Please enter a valid integer.");
//            }
//        }
//
//
//        // Retrieve the conversation
//       //  Conversation conversation = chatBox.getConversation(userAID, userBID);
//        Conversation conversation = chatBox.getConversation(userAID, userBID);
//        if ( conversation == null ){
//            Conversation newConversation =  chatBox.addConversation(userAID, userBID );
//            //if ( newConversation != null ){ System.out.println("Error");}
//
//            db.addConversation(userAID , userBID , newConversation.getConversationID()); // new DB entry .
//
//            conversation = chatBox.getConversation(userAID, userBID);
//        }
//
//
//
//        if (conversation != null) {
//            System.out.println("Conversation started between User " + userAID + " and User " + userBID);
//
//            // Loop to send messages from User A to User B
//            String messageText;
//            while (true) {
//                System.out.print("Enter a message from User " + userAID + " to User " + userBID + " (or type 'exit' to finish): ");
//                messageText = scanner.nextLine().trim();
//
//                if (messageText.equalsIgnoreCase("exit")) {
//                    break;
//                }
//
//                Message toadd = conversation.addMessage(messageText, userAID );
//                db.addMessage(toadd);
//
//            }
//
//            // Display the conversation
//            conversation.displayConversation();
//        }
//
//        // Display total number of conversations
//        System.out.println("Total number of conversations: " + chatBox.getNumberOfConversations());
//    }
//
//
//


}
