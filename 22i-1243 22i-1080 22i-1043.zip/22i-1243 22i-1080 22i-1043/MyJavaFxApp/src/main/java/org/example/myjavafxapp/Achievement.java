package org.example.myjavafxapp;

import java.util.Date;

public class Achievement {

    private int achievementID;
    private int userID;
    private String title;
    private String description;
    private Date date;



    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }

    // Constructor - for creating a new achievement
    public Achievement(int userID, String title, String description , Date date) {
        this.achievementID = generateUniqueID();
        this.userID = userID;
        this.title = title;
        this.description = description ;
        this.date = date ;
    }

    // Constructor - loading from DB
    public Achievement(int achievementID, int userID, String title, String description , Date date) {
        this.achievementID = achievementID;
        this.userID = userID;
        this.title = title;
        this.description = description ;
        this.date = date;
        generateUniqueID(); // If needed, validate or regenerate ID here
    }




    // Method to add or update achievement details
    public void addAchievement(String title, String description ) {
        this.title = title;
        this.description = description ;
        this.date = new Date(); // Updates the date to the current date
    }

    // Getters and Setters
    public int getAchievementID() {
        return achievementID;
    }

    public void setAchievementID(int achievementID) {
        this.achievementID = achievementID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription () {
        return description ;
    }

    public void setDescription (String description )  {
        this.description = description ;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
