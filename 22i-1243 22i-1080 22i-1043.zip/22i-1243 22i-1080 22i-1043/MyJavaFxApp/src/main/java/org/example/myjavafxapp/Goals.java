package org.example.myjavafxapp;

import java.util.Date;

public class Goals {
    private int goalID;
    private int userID;
    private String description;
    private Date deadline;
    private int financialGoal;


    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }



    // Constructor
    public Goals(int userID, String description, Date deadline) {
        this.goalID = generateUniqueID();
        this.userID = userID;
        this.description = description;
        this.deadline = deadline;
        this.financialGoal = 0; // Initially zero until set
    }

    // loading form DB
    public Goals(int goalID, int userID, String description, Date deadline, int financialGoal) {
        this.goalID = goalID;
        this.userID = userID;
        this.description = description;
        this.deadline = deadline;
        this.financialGoal = financialGoal;
        generateUniqueID(); // Just in case ID needs validation or regeneration
    }

    public void setFinancialGoal(int financialGoal) {
        this.financialGoal = financialGoal;
    }


    public void setGoalDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public int getGoalID() {
        return goalID;
    }

    public void setGoalID(int goalID) {
        this.goalID = goalID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDeadline() {
        return deadline;
    }

    public int getFinancialGoal() {
        return financialGoal;
    }
}
