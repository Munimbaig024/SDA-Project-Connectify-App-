package org.example.myjavafxapp;

public class Message {

    // Static variable to keep track of the message ID
    private static int idCounter = 0;

    // Attributes
    private String text;
    private final int msgID;
    private int senderID;
    private final int conversationID;

    // Constructors

    // if loading old messages
    public Message(String text , int senderID , int conversationID ,  int msgID ) {
        this.text = text;
        this.senderID = senderID;
        this.msgID = msgID;
        this.conversationID = conversationID;
        generateUniqueID();
    }


    // for a new message
    public Message(String text, int senderID , int conversationID ) {
        this.text = text;
        this.senderID = senderID;
        this.msgID = generateUniqueID();
        this.conversationID = conversationID;
    }



    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter; // Increments and assigns the value to msgID
    }

    // Getters and Setters
    public int getMsgID() {
        return msgID;
    }

    public int getSenderID() {
        return senderID;
    }

    public void setSenderID(int senderID) {
        this.senderID = senderID;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    int getConversationID() {return conversationID;}
}
