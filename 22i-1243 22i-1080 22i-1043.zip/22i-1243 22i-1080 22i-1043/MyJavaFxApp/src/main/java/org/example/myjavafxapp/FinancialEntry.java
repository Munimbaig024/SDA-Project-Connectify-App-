package org.example.myjavafxapp;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

public class FinancialEntry {

    // Attributes
    private int entryID;
    private int financialID;
    private int expenses;
    private int income;
    private int profitOrLoss;
    private Date date;         // Date of data entry



    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }

    // Constructor to load from Db , call from Financial Data class not in DB directly
    public FinancialEntry(int entryID, int financialID, int expenses, int income, Date date) {
        this.entryID = entryID;
        this.financialID = financialID;
        this.expenses = expenses;
        this.income = income;
        calculateProfitOrLoss(); // Calculates profit/loss during instantiation
        this.date = date;
        generateUniqueID() ; // keep track
    }

    // Constructor to add new entry
    public FinancialEntry( int financialID, int expenses, int income , Date date) {

        this.entryID = generateUniqueID();
        this.financialID = financialID;
        this.expenses = expenses;
        this.income = income;
        this.date = date;
        calculateProfitOrLoss(); // Calculates profit/loss during instantiation
    }

    // Method to add data (set new values and recalculate profit/loss)
    public void addData(int expenses, int income) {
        this.expenses = expenses;
        this.income = income;
        calculateProfitOrLoss();
    }

    // Method to calculate profit or loss based on income and expenses
    private void calculateProfitOrLoss() {
        this.profitOrLoss = this.income - this.expenses;
    }

    // Getters and Setters
    public int getEntryID() {
        return entryID;
    }

    public void setEntryID(int entryID) {
        this.entryID = entryID;
    }

    public int getFinancialID() {
        return financialID;
    }

    public void setFinancialID(int financialID) {
        this.financialID = financialID;
    }

//    public void setDate(Date date) {
//        this.date = date;
//    }

    public Date getDate() {return date;}

    public int getExpenses() {
        return expenses;
    }

    public int getIncome() {
        return income;
    }

    public int getProfitOrLoss() {
        return profitOrLoss;
    }

    @Override
    public String toString() {
        return "FinancialEntry{" +
                "entryID=" + entryID +
                ", financialID=" + financialID +
                ", expenses=" + expenses +
                ", income=" + income +
                ", profitOrLoss=" + profitOrLoss +
                '}';
    }


    public  int  getYear () {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1; // Months are 0-based, so add 1



        return year ;

    }

    public int getMonth () {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1; // Months are 0-based, so add 1



        return month ;
    }

}
