package org.example.myjavafxapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler {

    // Database credentials
    private final String jdbcUrl = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
    private final String username = "talhaazim";  // Replace with your DB username
    private final String password = "123456789";  // Replace with your DB password


    // making DB a singleton
    // Static instance of the singleton
    private static DBHandler instance;


    private DBHandler() {}

    // Public method to provide access to the instance
    public static DBHandler getInstance() {
        if (instance == null) { // Check if the instance is null

            synchronized (DBHandler.class) { // Double-checked locking for thread safety
                if (instance == null) {
                    instance = new DBHandler();
                }
            }// synchronized.
        }
        return instance;
    }

    // load all the data in the beginning.
    public void loadData (Connectify conn) {
        this.LoadUsers (conn.getUsers() );
        this.loadMeetings(conn.getMeetings() );
        this.LoadEvents (conn.getEvents() );

        this.LoadConversation (conn.getChatBox() ) ;




    }





    public void addUser(User user, String type) {

        String query = "INSERT INTO Users (userID, name, email, password, createdAt, userType, industry, teamSize) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the values for the prepared statement
            preparedStatement.setInt(1, user.getUserID());
            preparedStatement.setString(2, user.getName());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setTimestamp(5, new java.sql.Timestamp(user.getCreatedAt().getTime())); // Convert Date to Timestamp

            // Set optional fields based on the user type
            if (type.equalsIgnoreCase("Startup")) {
                preparedStatement.setString(6, "Startup" ); // User type (Startup )

                preparedStatement.setString(7, user.getIndustry());
                preparedStatement.setInt(8, user.getTeamSize() );

            } else if (type.equalsIgnoreCase("BiggerCompany" )) {
                preparedStatement.setString(6, "BiggerCompany"); // User type ( BiggerCompany)

                preparedStatement.setString(7, user.getIndustry());
                preparedStatement.setInt (8, user.getTeamSize() );
            } else {
                throw new IllegalArgumentException("Invalid user type: " + type);
            }

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User successfully added to the database.");
            } else {
                System.out.println("Failed to add the user to the database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // isi ke inside financial entries ???? no , i think this calls when a user is created and then nvr called
    // make a seperate function for entries
    public void AddFinancialData(FinancialData financialData) {

        String insertSQL = "INSERT INTO FinancialData (financialID, userID, cumulativeIncome, cumulativeExpenses, profitOrLoss, progressGraph) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, financialData.getFinancialID());
            preparedStatement.setInt(2, financialData.getUserID());
            preparedStatement.setInt(3, financialData.getCumulativeIncome());
            preparedStatement.setInt(4, financialData.getCumulativeExpenses());
            preparedStatement.setInt(5, financialData.getProfitOrLoss());
            preparedStatement.setString(6, financialData.getProgressGraph());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
//                System.out.println("Financial data added successfully for User ID: " + financialData.getUserID());
                System.out.println(" ");
            } else {
                System.out.println("Failed to add financial data for User ID: " + financialData.getUserID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding financial data to the database.");
        }
    }


    public void AddFinancialEntry(FinancialEntry financialEntry) {
        // SQL Insert Query for FinancialEntry
        String insertSQL = "INSERT INTO FinancialEntry (entryID, financialID, expenses, income, profitOrLoss, entryDate) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        // SQL Update Query for FinancialData
        String updateSQL = "UPDATE FinancialData " +
                "SET cumulativeExpenses = cumulativeExpenses + ?, " +
                "    cumulativeIncome = cumulativeIncome + ?, " +
                "    profitOrLoss = profitOrLoss + ? " +
                "WHERE financialID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            // Start transaction
            connection.setAutoCommit(false);

            // Insert FinancialEntry
            try (PreparedStatement insertStatement = connection.prepareStatement(insertSQL)) {
                // Set parameters for the prepared statement
                insertStatement.setInt(1, financialEntry.getEntryID());
                insertStatement.setInt(2, financialEntry.getFinancialID());
                insertStatement.setInt(3, financialEntry.getExpenses());
                insertStatement.setInt(4, financialEntry.getIncome());
                insertStatement.setInt(5, financialEntry.getProfitOrLoss());
                insertStatement.setTimestamp(6, new java.sql.Timestamp(financialEntry.getDate().getTime())); // Convert Date to SQL Timestamp

                // Execute the insert query
                int rowsInserted = insertStatement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Financial entry added successfully with Entry ID: " + financialEntry.getEntryID());
                } else {
                    System.out.println("Failed to add financial entry with Entry ID: " + financialEntry.getEntryID());
                    connection.rollback(); // Rollback transaction if insertion fails
                    return;
                }
            }

            // Update FinancialData
            try (PreparedStatement updateStatement = connection.prepareStatement(updateSQL)) {
                // Set parameters for the update statement
                updateStatement.setInt(1, financialEntry.getExpenses());
                updateStatement.setInt(2, financialEntry.getIncome());
                updateStatement.setInt(3, financialEntry.getProfitOrLoss());
                updateStatement.setInt(4, financialEntry.getFinancialID());

                // Execute the update query
                int rowsUpdated = updateStatement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("FinancialData updated successfully for Financial ID: " + financialEntry.getFinancialID());
                } else {
                    System.out.println("Failed to update FinancialData for Financial ID: " + financialEntry.getFinancialID());
                    connection.rollback(); // Rollback transaction if update fails
                    return;
                }
            }

            // Commit transaction
            connection.commit();

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding financial entry or updating financial data.");
        }
    }




    public void addGoal(Goals goal) {
        // SQL Insert Query
        String insertSQL = "INSERT INTO Goals (goalID, userID, description, deadline, financialGoal) " +
                "VALUES (?, ?, ?, ?, ?)";


        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, goal.getGoalID());
            preparedStatement.setInt(2, goal.getUserID());
            preparedStatement.setString(3, goal.getDescription());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(goal.getDeadline().getTime())); // Convert Date to SQL Timestamp
            preparedStatement.setInt(5, goal.getFinancialGoal());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Goal added successfully with Goal ID: " + goal.getGoalID());
            } else {
                System.out.println("Failed to add goal with Goal ID: " + goal.getGoalID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding goal to the database.");
        }
    }


    public void addService(Service service) {
        // SQL Insert Query
        String insertSQL = "INSERT INTO Services (serviceID, userID, name, description, category, basePrice, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";


        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, service.getServiceID());
            preparedStatement.setInt(2, service.getUserID());
            preparedStatement.setString(3, service.getName());
            preparedStatement.setString(4, service.getDescription());
            preparedStatement.setString(5, service.getCategory());
            preparedStatement.setInt(6, service.getBasePrice());
            preparedStatement.setString(7, service.getStatus());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Service added successfully with Service ID: " + service.getServiceID());
            } else {
                System.out.println("Failed to add service with Service ID: " + service.getServiceID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding service to the database.");
        }

    }

    public void addAchievement(Achievement achievement) {
        // SQL Insert Query
        String insertSQL = "INSERT INTO Achievements (achievementID, userID, title, description, achievementDate) " +
                "VALUES (?, ?, ?, ?, ?)";


        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, achievement.getAchievementID()) ;
            preparedStatement.setInt(2, achievement.getUserID()) ;
            preparedStatement.setString(3, achievement.getTitle()) ;
            preparedStatement.setString(4, achievement.getDescription()) ;
            preparedStatement.setDate(5, new java.sql.Date(achievement.getDate().getTime()) ) ; // Convert Date to SQL Date

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Achievement added successfully with Achievement ID: " + achievement.getAchievementID());
            } else {
                System.out.println("Failed to add achievement with Achievement ID: " + achievement.getAchievementID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding achievement to the database.");
        }

    }


    public void addMeeting(Meeting meeting) {
        // SQL Insert Query
        String insertSQL = "INSERT INTO Meetings (meetingID, userAID, userBID, timeSlot, status) " +
                "VALUES (?, ?, ?, ?, ?)";


        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, meeting.getMeetingID());
            preparedStatement.setInt(2, meeting.getUserAID());
            preparedStatement.setInt(3, meeting.getUserBID());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(meeting.getTimeSlot().getTime())); // Convert Date to SQL Timestamp
            preparedStatement.setString(5, meeting.getStatus());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Meeting added successfully with Meeting ID: " + meeting.getMeetingID());
            } else {
                System.out.println("Failed to add meeting with Meeting ID: " + meeting.getMeetingID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding meeting to the database.");
        }
    }



    public void addNotification(Notification notification) {
        // SQL Insert Query
        String insertSQL = "INSERT INTO Notifications (notificationID, userID, message, timeStamp, readStatus, type) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set parameters for the prepared statement
            preparedStatement.setInt(1, notification.getNotificationID());
            preparedStatement.setInt(2, notification.getUserID());
            preparedStatement.setString(3, notification.getMessage());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(notification.getTimeStamp().getTime())); // Convert Date to SQL Timestamp
            preparedStatement.setString(5, notification.getReadStatus());
            preparedStatement.setString(6, notification.getType());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Notification added successfully with Notification ID: " + notification.getNotificationID());
            } else {
                System.out.println("Failed to add notification with Notification ID: " + notification.getNotificationID());
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding notification to the database.");
        }
    }



    public void addJob(Job job) {
        String query = "INSERT INTO Jobs (jobID, userID, title, description, category, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try ( Connection connection = DriverManager.getConnection(jdbcUrl, username, password ) ;
              PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the values for the prepared statement
            preparedStatement.setInt(1, job.getJobID());
            preparedStatement.setInt(2, job.getUserID());
            preparedStatement.setString(3, job.getTitle());
            preparedStatement.setString(4, job.getDescription());
            preparedStatement.setString(5, job.getCategory());
            preparedStatement.setString(6, job.getStatus());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Job successfully added to the database.");
            } else {
                System.out.println("Failed to add the job to the database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addJobApplication (JobApplication jobApplication) {
        String query = "INSERT INTO JobApplications (applicantID, jobID, startupID, coverLetter, submittedDate, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection( jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {


            preparedStatement.setInt(1, jobApplication.getApplicantID());
            preparedStatement.setInt(2, jobApplication.getJobID());
            preparedStatement.setInt(3, jobApplication.getStartupID());
            preparedStatement.setString(4, jobApplication.getCoverLetter());
            preparedStatement.setTimestamp(5, new java.sql.Timestamp(jobApplication.getSubmittedDate().getTime()));
            preparedStatement.setString(6, jobApplication.isStatus() ? "T" : "F");

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Job application successfully added to the database.");
            } else {
                System.out.println("Failed to add the job application to the database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void addMessage(Message msg ) {
        String insertSQL = "INSERT INTO Messages (msgID, text, senderID, conversationID ) VALUES (?, ?, ?, ? )";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set values from the Message object
            preparedStatement.setInt(1, msg.getMsgID());
            preparedStatement.setString(2, msg.getText());
            preparedStatement.setInt(3, msg.getSenderID());
            preparedStatement.setInt(4, msg.getConversationID());


            // Execute the insert statement
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Message added successfully!");
            } else {
                System.out.println("Failed to add message.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addConversation(int conversationID, int userAID, int userBID ) {
        String insertSQL = "INSERT INTO Conversation (conversationID, userAID, userBID ) VALUES (?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set values for the INSERT statement
            preparedStatement.setInt(1, conversationID);
            preparedStatement.setInt(2, userAID);
            preparedStatement.setInt(3, userBID);

            // Execute the insert statement
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Conversation added successfully!");
            } else {
                System.out.println("Failed to add conversation.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void addEvent(Events event) {

        // SQL query to insert event data
        String insertSQL = "INSERT INTO Events (event_ID, user_ID, name, description, eventDateTime, location) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {

            // Set the parameters for the prepared statement
            preparedStatement.setInt(1, event.getEventID());
            preparedStatement.setInt(2, event.getUserID());
            preparedStatement.setString(3, event.getName());
            preparedStatement.setString(4, event.getDescription());

            // Convert java.util.Date to java.sql.Timestamp
            java.sql.Timestamp sqlTimestamp = new java.sql.Timestamp(event.getDate().getTime());
            preparedStatement.setTimestamp(5, sqlTimestamp);

            preparedStatement.setString(6, event.getLocation());

            // Execute the update
            int rowsAffected = preparedStatement.executeUpdate();

            // Feedback
            if (rowsAffected > 0) {
                System.out.println("Event successfully added to the database.");
            } else {
                System.out.println("Failed to add the event to the database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /////////////////////////////////////  Loading From DataBase methods ////////////////////////////////////////////////





// when we load a user basically all data associated with it like Jobs / its applications will be loaded in this Instance.

    public void LoadUsers(List<User> users) {
        String query = "SELECT userID, name, email, password, createdAt , userType , industry, teamSize FROM Users";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password ) ;
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Iterate over the result set
            while (resultSet.next()) {
                int userID = resultSet.getInt("userID");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");

                Date createdAt = new Date(resultSet.getTimestamp("createdAt").getTime());


                String industry = resultSet.getString("industry");
                int teamSize = resultSet.getInt("teamSize");
                String accountType = resultSet.getString("userType");

                // Determine the account type and create the appropriate object
                if ("BiggerCompany".equalsIgnoreCase(accountType)) {
                    User biggerCompany = new BiggerCompany(userID, name, email, password, createdAt, industry, teamSize);
                    this.loadJobs(biggerCompany);
                    this.loadNotifications (biggerCompany);
                    users.add(biggerCompany);
                } else if ("Startup".equalsIgnoreCase(accountType)) {
                    User startup = new Startup(userID, name, email, password, createdAt, industry, teamSize);
                    this.loadFinancialData (startup);
                    this.loadServices(startup);
                    this.loadAchievements(startup);
                    this.loadGoals(startup);
                    this.loadNotifications (startup);
//
                    users.add(startup);
                } else {
                    System.out.println("Unknown account type for userID: " + userID);
                }
            }

            System.out.println("Users loaded successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error loading users from the database.");
        }
    }


    // Bigger Company has array of Jobs
    public void loadJobs(User user) {

        // Check if the user is a BiggerCompany
        if (user.getClass() == BiggerCompany.class) {
            BiggerCompany biggerCompany = (BiggerCompany) user;

            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password )  ;
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "SELECT * FROM Jobs WHERE userID = ?")) {

                // Set the userID parameter
                preparedStatement.setInt(1, user.getUserID());

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Process the result set
                while (resultSet.next()) {
                    int jobID = resultSet.getInt("jobID");
                    String title = resultSet.getString("title");
                    String description = resultSet.getString("description");
                    String category = resultSet.getString("category");
                    String status = resultSet.getString("status");

                    // Create a Job object
                    Job job = new Job(jobID, user.getUserID(), title, description, category, status);

                    // Add the job to the BiggerCompany's jobs array
                    biggerCompany.addJob(job);
                }

                System.out.println("Jobs successfully loaded for BiggerCompany: " + user.getName());

            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error loading jobs for BiggerCompany: " + user.getName());
            }
        } else {
            System.out.println("The provided user is not a BiggerCompany. Cannot load jobs.");
        }
    }


    public void loadServices(User userS) {

        if (userS.getClass() == Startup.class) {

            Startup user = (Startup) userS;


            // SQL Query to fetch services for the given user
            String selectServicesSQL = "SELECT serviceID, userID, name, description, category, basePrice, status " +
                    "FROM Services WHERE userID = ?";


            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 PreparedStatement preparedStatement = connection.prepareStatement(selectServicesSQL)) {

                // Set the userID parameter for the query
                preparedStatement.setInt(1, user.getUserID());

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Iterate through the results and create Service objects
                while (resultSet.next()) {
                    int serviceID = resultSet.getInt("serviceID");
                    int userID = resultSet.getInt("userID");
                    String name = resultSet.getString("name");
                    String description = resultSet.getString("description");
                    String category = resultSet.getString("category");
                    int basePrice = resultSet.getInt("basePrice");
                    String status = resultSet.getString("status");

                    // Create a new Service object using the constructor
                    Service service = new Service(serviceID, userID, name, description, category, basePrice, status);

                    // Add the service to the user
                    user.addService(service);
                }

                System.out.println("Services loaded successfully for user ID: " + user.getUserID());

            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error loading services for user ID: " + user.getUserID());
            }
        }
    }

    public void loadGoals(User userS ) {

        if (userS.getClass() == Startup.class) {

            Startup user = (Startup) userS;
            // SQL Query to fetch goals for the given user
            String selectGoalsSQL = "SELECT goalID, userID, description, deadline, financialGoal " +
                    "FROM Goals WHERE userID = ?";


            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 PreparedStatement preparedStatement = connection.prepareStatement(selectGoalsSQL)) {

                // Set the userID parameter for the query
                preparedStatement.setInt(1, user.getUserID());

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Iterate through the results and create Goals objects
                while (resultSet.next()) {
                    int goalID = resultSet.getInt("goalID");
                    int userID = resultSet.getInt("userID");
                    String description = resultSet.getString("description");
                    Date deadline = new Date(resultSet.getTimestamp("deadline").getTime()); // Convert to Date
                    int financialGoal = resultSet.getInt("financialGoal");

                    // Create a new Goals object using the constructor
                    Goals goal = new Goals(goalID, userID, description, deadline, financialGoal);

                    // Add the goal to the user
                    user.addGoal(goal);
                }

                System.out.println("Goals loaded successfully for user ID: " + user.getUserID());

            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error loading goals for user ID: " + user.getUserID());
            }
        }
    }

    public void loadAchievements(User userS ) {

        if (userS.getClass() == Startup.class) {

            Startup user = (Startup) userS;
            // SQL Query to fetch achievements for the given user
            String selectAchievementsSQL = "SELECT achievementID, userID, title, description, achievementDate " +
                    "FROM Achievements WHERE userID = ?";


            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 PreparedStatement preparedStatement = connection.prepareStatement(selectAchievementsSQL)) {

                // Set the userID parameter for the query
                preparedStatement.setInt(1, user.getUserID());

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Iterate through the results and create Achievement objects
                while (resultSet.next()) {
                    int achievementID = resultSet.getInt("achievementID");
                    int userID = resultSet.getInt("userID");
                    String title = resultSet.getString("title");
                    String description = resultSet.getString("description");
                    Date date = new Date(resultSet.getDate("achievementDate").getTime()); // Convert to Date

                    // Create a new Achievement object using the constructor
                    Achievement achievement = new Achievement(achievementID, userID, title, description, date);

                    // Add the achievement to the user
                    user.addAchievement(achievement);
                }

                System.out.println("Achievements loaded successfully for user ID: " + user.getUserID());

            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error loading achievements for user ID: " + user.getUserID());
            }
        }

    }


    // this functionality is for startups only.
    public void loadFinancialData(User userS ) {


        if (userS.getClass() == Startup.class) {

            Startup user = (Startup) userS ;
            // SQL Queries
            String selectFinancialDataSQL = "SELECT financialID, cumulativeIncome, cumulativeExpenses, profitOrLoss, progressGraph " +
                    "FROM FinancialData WHERE userID = ?";
            String selectFinancialEntriesSQL = "SELECT entryID, expenses, income, profitOrLoss, entryDate " +
                    "FROM FinancialEntry WHERE financialID = ?";


            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 PreparedStatement financialDataStatement = connection.prepareStatement(selectFinancialDataSQL)) {

                // Set the user ID parameter for the financial data query
                financialDataStatement.setInt(1, user.getUserID());

                // Execute the financial data query
                ResultSet resultSetFinancialData = financialDataStatement.executeQuery();

                if (resultSetFinancialData.next()) {
                    // Retrieve financial data
                    int financialID = resultSetFinancialData.getInt("financialID");
                    int cumulativeIncome = resultSetFinancialData.getInt("cumulativeIncome");
                    int cumulativeExpenses = resultSetFinancialData.getInt("cumulativeExpenses");
                    int profitOrLoss = resultSetFinancialData.getInt("profitOrLoss");
                    String progressGraph = resultSetFinancialData.getString("progressGraph");

                    // Initialize financial data for the user
                    user.initialize_FinancialData_with_this_ID(financialID);

                    FinancialData temp1 = user.getFinancialData();
//                    temp1.setCumulativeIncome(cumulativeIncome);
//                    temp1.setCumulativeExpenses(cumulativeExpenses);
//                    temp1.setProfitOrLoss(profitOrLoss);
                    temp1.setProgressGraph(progressGraph);

                    // Fetch and load financial entries
                    try (PreparedStatement financialEntriesStatement = connection.prepareStatement(selectFinancialEntriesSQL)) {
                        // Set the financialID parameter for the entries query
                        financialEntriesStatement.setInt(1, financialID);

                        // Execute the financial entries query
                        ResultSet resultSetFinancialEntries = financialEntriesStatement.executeQuery();

                        while (resultSetFinancialEntries.next()) {
                            int entryID = resultSetFinancialEntries.getInt("entryID");
                            int expenses = resultSetFinancialEntries.getInt("expenses");
                            int income = resultSetFinancialEntries.getInt("income");

                            Date entryDate = new Date (resultSetFinancialEntries.getTimestamp("entryDate").getTime() ) ; // Convert to Date

                            // Add entry to the financial data
                            temp1.enterData(entryID, expenses, income, entryDate);
                        }
                    }

                    System.out.println("Financial data and entries loaded successfully for user ID: " + user.getUserID());
                } else {
                    System.out.println("No financial data found for user ID: " + user.getUserID());
                }

            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error loading financial data and entries from the database.");
            }
        }

    }




    public void LoadEvents( List<Events> eventsList ) {


        String query = "SELECT event_ID, user_ID, name, description, eventDateTime, location FROM Events ORDER BY event_ID ASC";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password );

             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                // Retrieve data from the result set
                int eventID = resultSet.getInt("event_ID");
                int userID = resultSet.getInt("user_ID");
                String name = resultSet.getString("name");
                String description = resultSet.getString("description");
//                Date date = resultSet.getTimestamp("eventDateTime"); // Retrieve as Timestamp and handle it as Date

                Date date = new Date(resultSet.getTimestamp("eventDateTime").getTime() );

                String location = resultSet.getString("location");

                // Create an Events object
                Events event = new Events(eventID, userID, name, description, date, location);

                // Add to the list
                eventsList.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }


    // messages are loaded within a Conversations
    public void LoadConversation(ChatBox chatBox) {
        String queryConversations = "SELECT conversationID, userAID, userBID FROM Conversation ORDER BY conversationID ASC";
        String queryMessages = "SELECT text, senderID, msgID FROM Messages WHERE conversationID = ? ORDER BY msgID ASC";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatementConversations = connection.prepareStatement(queryConversations);
             ResultSet resultSetConversations = preparedStatementConversations.executeQuery()) {

            List<Conversation> conversations = new ArrayList<>();

            while (resultSetConversations.next()) {
                int conversationID = resultSetConversations.getInt("conversationID");
                int userAID = resultSetConversations.getInt("userAID");
                int userBID = resultSetConversations.getInt("userBID");

                // Create Conversation instance
                Conversation conversation = new Conversation(conversationID, userAID, userBID);

                // Retrieve messages for the current conversation
                try (PreparedStatement preparedStatementMessages = connection.prepareStatement(queryMessages)) {
                    preparedStatementMessages.setInt(1, conversationID);
                    try (ResultSet resultSetMessages = preparedStatementMessages.executeQuery()) {
                        while (resultSetMessages.next()) {
                            String text = resultSetMessages.getString("text");
                            int senderID = resultSetMessages.getInt("senderID");
                            int msgID = resultSetMessages.getInt("msgID");  // Extract msgID

                            // Add each message to the conversation
                            conversation.loadMessage(text, senderID, msgID );
                        }
                    }
                }

                // Add the conversation with its messages to the list
                conversations.add(conversation);
            }

            // Set the loaded conversations in ChatBox
            chatBox.setConversations(conversations);

            System.out.println("Conversations and messages loaded successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void loadNotifications(User user) {
//        // Ensure user is not null
//        if (user == null) {
//            System.err.println("User cannot be null.");
//            return;
//        }

        // SQL Query to fetch notifications for a specific user
        String selectNotificationsSQL = "SELECT notificationID, userID, message, timeStamp, readStatus, type " +
                "FROM Notifications WHERE userID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(selectNotificationsSQL)) {

            // Set the userID parameter in the query
            preparedStatement.setInt(1, user.getUserID());

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Fetch the notifications list from the user object
            List<Notification> notifications = user.getNotifications();

            // Iterate through the results and create Notification objects
            while (resultSet.next()) {
                int notificationID = resultSet.getInt("notificationID");
                int userID = resultSet.getInt("userID");
                String message = resultSet.getString("message");
                Date timeStamp = new Date(resultSet.getTimestamp("timeStamp").getTime()); // Convert to Date
                String readStatus = resultSet.getString("readStatus");
                String type = resultSet.getString("type");

                // Create a new Notification object using the DB constructor
                Notification notification = new Notification(notificationID, userID, message, timeStamp, readStatus, type);

                // Add the notification to the user's notifications list
                notifications.add(notification);
            }

            System.out.println("Notifications loaded successfully for user ID: " + user.getUserID());

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading notifications for user ID: " + user.getUserID());
        }
    }


    public void loadMeetings(List<Meeting> meetings) {
        // SQL query to fetch meeting data
        String selectMeetingsSQL = "SELECT meetingID, userAID, userBID, timeSlot, status " +
                "FROM Meetings";


        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(selectMeetingsSQL)) {

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Process the result set
            while (resultSet.next()) {
                int meetingID = resultSet.getInt("meetingID");
                int userAID = resultSet.getInt("userAID");
                int userBID = resultSet.getInt("userBID");
                Date timeSlot = new Date(resultSet.getTimestamp("timeSlot").getTime()); // Convert SQL Timestamp to Java Date
                String status = resultSet.getString("status");

                // Create a Meeting object using the constructor
                Meeting meeting = new Meeting(meetingID, userAID, userBID, timeSlot, status);

                // Add the meeting to the provided list
                meetings.add(meeting);
            }

            System.out.println("Meetings loaded successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading meetings.");
        }
    }


    ///////////////////////// Update Operations ( mostly status updates ) /////////////////////////////////////

    public void updateNotificationStatus(int notificationID) {
        // SQL Update Query to set the notification's status to 'read'
        String updateSQL = "UPDATE Notifications " +
                "SET readStatus = 'read' " +
                "WHERE notificationID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            preparedStatement.setInt(1, notificationID);

            // Execute the update query
            int rowsAffected = preparedStatement.executeUpdate();


            if (rowsAffected > 0) {
                System.out.println("Notification status updated successfully for Notification ID: " + notificationID);
            } else {
                System.out.println("No notification found with Notification ID: " + notificationID);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error updating notification status for Notification ID: " + notificationID);
        }
    }


    // this is Job Applications submitted by the start-ups.
    public void updateApplicationStatus(int applicationID) {
        // SQL Update Query to set the status to 'T' for the given applicationID
        String updateSQL = "UPDATE JobApplications " +
                "SET status = 'T' " +
                "WHERE applicantID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            // Set the applicantID parameter in the query
            preparedStatement.setInt(1, applicationID);

            // Execute the update query
            int rowsAffected = preparedStatement.executeUpdate();

            // Provide feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Application status updated to 'T' successfully for Applicant ID: " + applicationID);
            } else {
                System.out.println("No application found with Applicant ID: " + applicationID);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error updating application status for Applicant ID: " + applicationID);
        }
    }

    public void updateMeetingStatus(int meetingID, String status) {
        // SQL Update Query to set the status for the given meetingID
        String updateSQL = "UPDATE Meetings " +
                "SET status = ? " +
                "WHERE meetingID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            // Set the parameters for the prepared statement
            preparedStatement.setString(1, status);
            preparedStatement.setInt(2, meetingID);

            // Execute the update query
            int rowsAffected = preparedStatement.executeUpdate();

            // Provide feedback to the user
            if (rowsAffected > 0) {
                System.out.println("Meeting status updated successfully to '" + status + "' for Meeting ID: " + meetingID);
            } else {
                System.out.println("No meeting found with Meeting ID: " + meetingID);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error updating meeting status for Meeting ID: " + meetingID);
        }
    }

    // Function to update the user's details
    public void editUser(User user, String name, String password, String industry, int teamSize) {

        String updateSQL = "UPDATE Users " +
                "SET name = ?, password = ?, industry = ?, teamSize = ? " +
                "WHERE userID = ?";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            // Set the parameters for the query
            preparedStatement.setString(1, name);            // Update name
            preparedStatement.setString(2, password);        // Update password (should be hashed in real use cases)
            preparedStatement.setString(3, industry);        // Update industry
            preparedStatement.setInt(4, teamSize);           // Update team size
            preparedStatement.setInt(5, user.getUserID());   // Identify user by userID

            // Execute the update query
            int rowsAffected = preparedStatement.executeUpdate();

            // Provide feedback to the user
            if (rowsAffected > 0) {
                System.out.println("User details updated successfully for User ID: " + user.getUserID());
            } else {
                System.out.println("Could not update details of User ID: " + user.getUserID() );
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error updating details for User ID: " + user.getUserID());
        }
    }


    /////////////////// Special Query ////////////////




}

