package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.List;

import java.util.Date;

public class Startup extends User {
    private String industry;
    private int teamSize;

    private  List<Achievement> achievements;

    private FinancialData financialData ;

    private  List<Goals> goals;
    private  List<Service> services;

    // Constructor - for creating a new startup
    public Startup( String name, String email, String password, String industry, int teamSize) {
        super( name, email, password); // Calls User constructor
        this.industry = industry;
        this.teamSize = teamSize;
        this.achievements = new ArrayList<>();

        financialData = new FinancialData(this.userID) ;

        DBHandler.getInstance().AddFinancialData(financialData); // in the DB ; new code

        this.goals = new ArrayList<>();
        this.services = new ArrayList<>();
    }

    // Constructor - loading from DB
    public Startup(int userID, String name, String email, String password, Date createdAt, String industry, int teamSize ) {
        super(userID, name, email, password, createdAt); // Calls User constructor
        this.industry = industry;
        this.teamSize = teamSize;
        this.achievements = new ArrayList<>();

//        financialData = new FinancialData(this.userID , financialDataID ) ;

        this.goals = new ArrayList<>();
        this.services = new ArrayList<>();
    }

    public void initialize_FinancialData_with_this_ID ( int financialDataID ) {

        financialData = new FinancialData(this.userID , financialDataID ) ;
    }

    // Method to show financial progress
    public void showFinancialProgress() {
        System.out.println("Financial Progress for Startup: " + name);
        financialData.generateReport();

    }

    // Method to add financial data
    public void addFinancialData ( int expenses, int income , Date date  ) {
        financialData.enterData ( expenses, income, date);

        System.out.println("Financial data added successfully.");
    }



//    // Function to enter data; it(entry) will auto generate a new ID
//    public void enterData( int expenses, int income , Date date ) {
//        FinancialEntry entry = new FinancialEntry( this.financialID, expenses, income , date );
//        entries.add(entry);
//        updateFinancialProgress();
//
//    }


    // Method to add a service
    public void addService(Service service) {
        services.add(service);
        System.out.println("Service added successfully: " + service.getName());
    }

    // Method to add an achievement
    public void addAchievement(Achievement achievement) {
        achievements.add(achievement);
        System.out.println("Achievement added successfully: " + achievement.getTitle());
    }

//    public Achievement extractAchievements( int id ) {
//        for ( Achievement a : achievements ) {
//            if ( a.getAchievementID() == id ) {
//                return a ;
//            }
//        }
//
//        return null;
//
//    }


    public void addGoal ( Goals goal) {

        goals.add(goal);

        System.out.println("Goal added successfully." );
    }

    // Method to check criteria (example: service category)
    public boolean checkCriteria(String category) {
        for (Service service : services) {
            if (service.getCategory().equalsIgnoreCase(category)) {
                //      System.out.println("Criteria met: Service found in category '" + category + "'.");
                return true;
            }
        }

        return false;
    }


    // Getters and Setters
    @Override
    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    @Override
    public int getTeamSize() {
        return teamSize;
    }

    public void setTeamSize(int teamSize) {
        this.teamSize = teamSize;
    }

    public  List<Achievement> getAchievements() {
        return achievements;
    }

    public void setAchievements(ArrayList<Achievement> achievements) {
        this.achievements = achievements;
    }


    public  List<Goals> getGoals() {
        return goals;
    }

    public void setGoals(ArrayList<Goals> goals) {
        this.goals = goals;
    }

    public List<Service> getServices() {
        return services;
    }

    public void setServices( List<Service> services) {
        this.services = services;
    }

    public FinancialData getFinancialData() {
        return financialData;
    }

    public void setFinancialData(FinancialData financialData) {
        this.financialData = financialData;
    }
}
