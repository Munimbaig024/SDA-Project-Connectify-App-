package org.example.myjavafxapp;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class FindSimilarStartupController implements Initializable {

    @FXML
    private Button viewProfileButton;

    @FXML
    private Label CompanyTitle;

    @FXML
    private Label StartupDashboardTitle;

    @FXML
    private Label StartupDashboardTitle1;

    @FXML
    private Button achievementButton;

    @FXML
    private ChoiceBox<String> categoryChoiceBox;
    private String[] categories = {
            "Web Development",
            "Mobile App Development",
            "Digital Marketing",
            "Software Development",
            "Cloud Computing",
            "Data Science",
            "Artificial Intelligence",
            "Cybersecurity",
            "IT Consulting",
            "E-commerce"
    };

    @FXML
    private Button chatButton;

    @FXML
    private ImageView companyImageField;

    @FXML
    private Button financialbutton;

    @FXML
    private Button goalButton;

    @FXML
    private Button logOutButton;

    @FXML
    private Button meetingButton;

    @FXML
    private Button notificationButton;

    @FXML
    private Button profitlossButton;

    @FXML
    private Button searchJobButton;

    @FXML
    private Button serviceButton;

    @FXML
    private Button similarStartupButton;

    @FXML
    private GridPane startupContainer;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Array of startups to display
//        List<StartupFront> startups = new ArrayList<>();
//        startups.add(new StartupFront("Startup A", "startupA@example.com", 10));
//        startups.add(new StartupFront("Startup B", "startupB@example.com", 20));
//        startups.add(new StartupFront("Startup C", "startupC@example.com", 15));
        categoryChoiceBox.getItems().addAll(categories);
        categoryChoiceBox.setOnAction(this::UpdateShortlistStartups);
    }

    private void UpdateShortlistStartups(ActionEvent event) {
        List<User> users = Connectify.getInstance().similarStartups(categoryChoiceBox.getSelectionModel().getSelectedItem());
        System.out.println(categoryChoiceBox.getSelectionModel().getSelectedItem());

        if (users.isEmpty()){
            System.out.println("No users found");
        }

        int column = 0;
        int row = 0;
        // Clear the container to avoid duplication
        startupContainer.getChildren().clear();

        // Dynamically load and display the cards
        for (User user : users) {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("startupCard.fxml"));
                AnchorPane startupCard = fxmlLoader.load();

                // Set the data in the controller
                StartupCardController controller = fxmlLoader.getController();
                controller.setData(user);

                // Add the card to the GridPane
                // Wrap to the next row after every 3 columns
                if (column == 1) {
                    column = 0;
                    row++;
                }

                startupContainer.add(startupCard, column++, row);
                ColumnConstraints columnConstraints = new ColumnConstraints();
                columnConstraints.setPrefWidth(483); // Preferred width for columns
                RowConstraints rowConstraints = new RowConstraints();
                rowConstraints.setPrefHeight(150); // Preferred height for rows
                startupContainer.getColumnConstraints().add(columnConstraints);
                startupContainer.getRowConstraints().add(rowConstraints);
                startupContainer.setPadding(new Insets(60, 0, 0, 0)); // Add padding around the grid
//                startupContainer.setHgap(10); // Horizontal gap between cells
//                startupContainer.setVgap(10); // Vertical gap between cells
//                Insets insets = new Insets(20, 30, 15, 5);  // Top: 20px, Left: 30px, Bottom: 15px, Right: 5px
//                GridPane.setMargin(startupCard, insets); // Optional for better spacing

                System.out.println("Loaded card for: " + user.getName());
            } catch (Exception e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Unable to load startup card");
                alert.setContentText("Failed to load a card for startup: " + user.getName());
                alert.showAndWait();
            }
        }
    }

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }

    @FXML
    public void ViewProfileButtonOnAction(ActionEvent event) {
        loadFXML("viewProfile.fxml", 872, 586);

        Stage currentStage = (Stage) viewProfileButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void SearchJobButtonOnAction(ActionEvent event) {
        loadFXML("searchJob.fxml", 872, 586);

        Stage currentStage = (Stage) searchJobButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void NotificationButtonOnAction(ActionEvent event) {
        loadFXML("notification.fxml", 872, 586);

        Stage currentStage = (Stage) notificationButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void FinancialButtonOnAction(ActionEvent event) {
        loadFXML("financialProgress.fxml", 872, 586);

        Stage currentStage = (Stage) financialbutton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void SimilarStartupButtonOnAction(ActionEvent event) {
        loadFXML("findSimilarStartup.fxml", 872, 586);
        Stage currentStage = (Stage) similarStartupButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void MeetingButtonOnAction(ActionEvent event)
    {
        loadFXML("scheduleMeeting.fxml", 872, 586);
        Stage currentStage = (Stage) meetingButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void GoalButtonOnAction(ActionEvent event)
    {
        loadFXML("setGoal.fxml", 872, 586);
        Stage currentStage = (Stage) goalButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ChatButtonOnAction(ActionEvent event)
    {
        loadFXML("startupChat.fxml", 872, 586);
        Stage currentStage = (Stage) chatButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ServiceButtonOnAction(ActionEvent event)
    {
        loadFXML("addService.fxml", 872, 586);
        Stage currentStage = (Stage) serviceButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void AchievementButtonOnAction(ActionEvent event)
    {
        loadFXML("displayAchievement.fxml", 872, 586);
        Stage currentStage = (Stage) achievementButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ProfitLossButtonOnAction(ActionEvent event)
    {
        loadFXML("storeProfitLoss.fxml", 872, 586);
        Stage currentStage = (Stage) profitlossButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void LogOutButtonOnAction(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), 600, 405);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();

            // Close the current stage
            Stage currentStage = (Stage) logOutButton.getScene().getWindow();
            // Apply fade-out transition to the current scene
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);

            // Set an action on fade transition completion
            fadeOut.setOnFinished(e -> currentStage.close());

            // Start the fade-out transition
            fadeOut.play();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Logout Error");
            alert.setContentText("Unable to logout and switch to the login screen.");
            alert.showAndWait();
        }
    }
}

