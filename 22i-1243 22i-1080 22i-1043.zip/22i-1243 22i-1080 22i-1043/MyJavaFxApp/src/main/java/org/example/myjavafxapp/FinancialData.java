package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FinancialData {

    // Attributes
    private int financialID;
    private int userID;
    private int cumulativeIncome;
    private int cumulativeExpenses;
    private int profitOrLoss;
    private String progressGraph; // This can hold graph data or be a placeholder for the graph's location
    private List<FinancialEntry> entries; // Array of FinancialEntry objects.



    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }


    // Constructor
    public FinancialData(int userID) {
        this.financialID = generateUniqueID();
        this.userID = userID;
        this.cumulativeIncome = 0;
        this.cumulativeExpenses = 0;
        this.profitOrLoss = 0;
        this.progressGraph = ""; // Can later be set to visualize progress
        this.entries = new ArrayList<>(); // Initializes the array of entries

    }


    // loading form DB.
    public FinancialData(int financialID, int userID) {
        this.financialID = financialID;
        this.userID = userID;
        this.cumulativeIncome = 0;
        this.cumulativeExpenses = 0;
        this.profitOrLoss = 0;
        this.progressGraph = ""; // Can later be set to visualize progress
        this.entries = new ArrayList<>(); // Initializes the array of entries
        generateUniqueID();
    }

    // Function to enter data from DB loading ;
    public void enterData(int entryID, int expenses, int income, Date date ) {
        FinancialEntry entry = new FinancialEntry(entryID, this.financialID, expenses, income, date );
        entries.add(entry);
        updateFinancialProgress();
    }


    // Function to enter data; it(entry) will auto generate a new ID
    public void enterData( int expenses, int income , Date date ) {
        FinancialEntry entry = new FinancialEntry( this.financialID, expenses, income , date );
        entries.add(entry);
        DBHandler.getInstance().AddFinancialEntry(entry);   ////; new code
        updateFinancialProgress();

    }


    // Method to update cumulative values and calculate profit/loss
    private void updateFinancialProgress() {
        cumulativeIncome = 0;
        cumulativeExpenses = 0;

        for (FinancialEntry entry : entries) {
            cumulativeIncome += entry.getIncome();
            cumulativeExpenses += entry.getExpenses();
        }
        profitOrLoss = cumulativeIncome - cumulativeExpenses;
//        drawGraph();
    }

    // progress graph: most likely to be related with java FX graphing tool
    private void drawGraph() {

        progressGraph = "Graph of cumulative profit/loss"; // This is where you'd implement graphing logic.
    }

    // Method to show a goal comparison (placeholder)
    public void showGoalComparison(int goalProfit) {
        if (profitOrLoss >= goalProfit) {
            System.out.println("Congratulations! You've met or exceeded your goal.");
        } else {
            int remaining = goalProfit - profitOrLoss;
            System.out.println("You are " + remaining + " away from your profit goal.");
        }
    }

    // Method to generate a financial report
    public void generateReport() {
        System.out.println("Financial Report:");
        System.out.println("Financial ID: " + financialID);
        System.out.println("User ID: " + userID);
        System.out.println("Cumulative Income: " + cumulativeIncome);
        System.out.println("Cumulative Expenses: " + cumulativeExpenses);
        System.out.println("Profit/Loss: " + profitOrLoss);
        System.out.println("Progress Graph: " + progressGraph);
        System.out.println("Entries:");
        for (FinancialEntry entry : entries) {
            System.out.println(entry);
        }
    }

    // Getters and Setters for attributes as needed
    public int getFinancialID() {
        return financialID;
    }

    public int getUserID() {
        return userID;
    }

    public int getCumulativeIncome() {
        return cumulativeIncome;
    }

    public int getCumulativeExpenses() {
        return cumulativeExpenses;
    }

    public int getProfitOrLoss() {
        return profitOrLoss;
    }

    public String getProgressGraph() {
        return progressGraph;
    }

    public List<FinancialEntry> getEntries() {
        return entries;
    }

    public void setProgressGraph(String progressGraph) {
        this.progressGraph = progressGraph ;
    }
}
