package org.example.myjavafxapp;

public class StartupFront {
    private String name;
    private String email;
    private int teamCount;

    public StartupFront(String name, String email, int teamCount) {
        this.name = name;
        this.email = email;
        this.teamCount = teamCount;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getTeamCount() {
        return teamCount;
    }
}

