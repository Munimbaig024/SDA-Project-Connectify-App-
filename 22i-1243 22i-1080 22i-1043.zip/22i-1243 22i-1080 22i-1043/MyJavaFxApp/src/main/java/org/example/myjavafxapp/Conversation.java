package org.example.myjavafxapp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Conversation {

    // Attributes
    private int userAID;
    private int userBID;
    private final int conversationID;
    private List<Message> messages;
//    private LocalDateTime createdAt;


    // Static variable to keep track of unique conversation IDs
    private static int conversationCounter = 0;

    // Constructor
    public Conversation(int userAID, int userBID) {
        this.userAID = userAID;
        this.userBID = userBID;
        this.conversationID = generateUniqueConversationID();
        this.messages = new ArrayList<>(); // Initialize the list of messages

        //this.createdAt = LocalDateTime.now(); // Sets creation date and time

    }

    // when loading conversation from DB.
    public Conversation(int userAID, int userBID, int conversationID) {
        this.userAID = userAID;
        this.userBID = userBID;
        this.conversationID = conversationID;
        generateUniqueConversationID(); // farig kam

        this.messages = new ArrayList<>(); // Initialize the list of messages

//        this.createdAt = createdAt; // Sets creation date and time

    }


    // Static method to generate unique conversation ID
    private static int generateUniqueConversationID() {
        return ++conversationCounter;
    }

    // Method to add a message to the conversation
    public Message addMessage(String text, int senderID  ) {
        Message newMessage = new Message(text, senderID , conversationID);

        messages.add(newMessage); // adding within the conversation
        return newMessage;

    }

    public void loadMessage (String text, int senderID , int msgId ) {
        Message newMessage = new Message(text, senderID , conversationID, msgId );

        messages.add(newMessage); // adding within the conversation


    }



    // Getters.
    public int getUserAID() {
        return userAID;
    }

    public int getUserBID() {
        return userBID;
    }

    public int getConversationID() {
        return conversationID;
    }

    public List<Message> getMessages() {
        return messages;
    }

//    public LocalDateTime getCreatedAt() {
//        return createdAt;
//    }

    // Display all messages in the conversation
    public void displayConversation() {
        //    System.out.println("Conversation ID: " + conversationID);
        for (Message message : messages) {
            System.out.println("Sender ID: " + message.getSenderID() + ", Message ID: " + message.getMsgID() + ", Text: " + message.getText());
        }
    }
}

