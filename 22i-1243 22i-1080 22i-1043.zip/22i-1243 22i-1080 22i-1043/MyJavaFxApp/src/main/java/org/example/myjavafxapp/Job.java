package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.List;


public class Job {
    private int jobID;
    private int userID;
    private String title;
    private String description;
    private String category;
    // I removed the location variable because it served no purpose : there is no physical Job
    private String status; // e.g., "open", "closed"
    private List<JobApplication> applications;



    // Static variable to keep track of the IDs
    private static int idCounter = 0;
    // Static method to generate unique ID
    private static int generateUniqueID() {
        return ++idCounter;
    }


    // Constructor - for creating a new job
    public Job(int userID, String title, String description, String category,  String status) {
        this.jobID = generateUniqueID();
        this.userID = userID;
        this.title = title;
        this.description = description;
        this.category = category;

        this.status = status;
        this.applications = new ArrayList<>(); // Initializes the array of job applications
    }

    // Constructor - loading from DB
    public Job(int jobID, int userID, String title, String description, String category,  String status) {
        this.jobID = jobID;
        this.userID = userID;
        this.title = title;
        this.description = description;
        this.category = category;

        this.status = status;
        this.applications = new ArrayList<>(); // Initializes the array of job applications: Will load in DB function.
        generateUniqueID();
    }



    // Method to add or update job details
    public void addDetails(String title, String description, String category,  String status) {
        this.title = title;
        this.description = description;
        this.category = category;

        this.status = status;
    }

    // Method to review job details
    public void reviewDetails() {
        System.out.println("Job ID: " + jobID);
        System.out.println("User ID: " + userID);
        System.out.println("Title: " + title);
        System.out.println("Description: " + description);
        System.out.println("Category: " + category);

        System.out.println("Status: " + status);
        System.out.println("Number of Applications: " + applications.size());
    }

    // Method to submit an application for this job
    public void submitApplication(JobApplication application) {
        applications.add(application);
        System.out.println("Application submitted successfully!");
    }

    // Method to select a job by ID from a list of jobs
    public static Job selectJob(ArrayList<Job> jobs, int jobID) {
        for (Job job : jobs) {
            if (job.getJobID() == jobID) {
                return job;
            }
        }
        System.out.println("Job with ID " + jobID + " not found.");
        return null;
    }

    // Getters and Setters
    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<JobApplication> getApplications() {
        return applications;
    }

    public void setApplications(ArrayList<JobApplication> applications) {
        this.applications = applications;
    }
}
