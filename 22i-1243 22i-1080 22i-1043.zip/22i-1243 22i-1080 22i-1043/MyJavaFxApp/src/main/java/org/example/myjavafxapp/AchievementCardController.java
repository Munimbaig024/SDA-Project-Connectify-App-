package org.example.myjavafxapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class AchievementCardController {

    @FXML
    private Label setDate;

    @FXML
    private TextArea setDescription;

    @FXML
    private Label setName;

    public void setData(Achievement achievement) {
        setName.setText(achievement.getTitle());
        System.out.println(achievement.getDate());
        String DateintoString = achievement.getDate().toString();
        setDate.setText(DateintoString);
        setDescription.setText(achievement.getDescription());
    }
}