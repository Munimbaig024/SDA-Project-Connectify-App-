package org.example.myjavafxapp;

//import javafx.scene.control.DatePicker;

import javafx.scene.control.DatePicker;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;


import java.util.ArrayList;
import java.util.List;

public class Connectify {

    private static Connectify instance; // Singleton instance
    private List<User> users;
    private List<Meeting> meetings;
    private List<Events> events;
    private ChatBox chatBox;

    public int currentUser ;


    // Private constructor to prevent instantiation from other classes
    private Connectify() {
        this.users = new ArrayList<>();
        this.meetings = new ArrayList<>();
        this.events = new ArrayList<>();
        this.chatBox = new ChatBox();

        // Load data from the database handler
        DBHandler.getInstance().loadData(this);
    }

    // Public method to provide access to the Singleton instance
    public static Connectify getInstance() {
        if (instance == null) {
            synchronized (Connectify.class) { // Thread-safe initialization
                if (instance == null) {
                    instance = new Connectify();
                }
            }
        }
        return instance;
    }

    // Getters
    public List<User> getUsers() {
        return users;
    }

    public List<Meeting> getMeetings() {
        return meetings;
    }

    public List<Events> getEvents() {
        return events;
    }

    public ChatBox getChatBox() {
        return chatBox;
    }

    // Function to get a User by ID
    public User getUser(int userID) {
        for (User user : users) {
            if (user.getUserID() == userID) {
                return user;
            }
        }
        System.out.println("User with ID " + userID + " not found.");
        return null;
    }

    public User getUserByCredentials ( String email, String password ) {

        for (User user : users) {

            if (Objects.equals(user.getEmail(), email) && Objects.equals(user.getPassword(), password)) {
                currentUser = user.getUserID();
                return user;
            }

        }

        // no user found , meaning invalid email / password
        return null;

    }


    // Function to get a conversation between two users, if there is not one it creates one.
    public Conversation getConversation(int userAID, int userBID) {

        // Retrieve the conversation
        Conversation conversation = chatBox.getConversation(userAID, userBID);
        if ( conversation == null ){
            Conversation newConversation =  chatBox.addConversation(userAID, userBID ); // this will add conversation in the ChatBox ( not the DB )

            DBHandler.getInstance().addConversation(userAID , userBID , newConversation.getConversationID()); // new DB entry .

            conversation = chatBox.getConversation(userAID, userBID);
            return  conversation;
        }

        return conversation;
    }



    public void send_a_message ( User user  ,int userBID , String textMessage ) {
        int userAID = user.getUserID(); // user A is the sender and user B is the receiver
        Conversation conversation = getConversation(userAID, userBID); // if it is a new conversation then DB is being handled by this function

        Message newMsg = conversation.addMessage(textMessage, userAID ); // in the conversation
        DBHandler.getInstance().addMessage(newMsg); // in the DB

    }

    // Function  to add a new User
    public void addUser (String name, String email, String password, String industry, int teamSize , String type )  {


        if (type.equalsIgnoreCase("BiggerCompany") ) {

            User newUser = new BiggerCompany( name, email, password, industry, teamSize );
            users.add(newUser);
            DBHandler.getInstance().addUser(newUser , "BiggerCompany");

            System.out.println("User added successfully: " + newUser.getName());
        }
        else {
            User newUser = new Startup( name, email, password, industry, teamSize );
            users.add(newUser);
            DBHandler.getInstance().addUser(newUser , "Startup");

            System.out.println("User added successfully: " + newUser.getName());

        }


    }


    public List<User> shortlistStartups (  String Category ) {

        return getUsers(Category);

    }

//
//    public  void editAchievement ( User user ) {
//
//        if( user.getClass() == Startup.class ) {
//            Startup startup = (Startup) user;
//
//
//        }
//
//    }


    public List <User > similarStartups (  String Category ) {

        return getUsers(Category);

    }

    private List<User> getUsers(String Category) {
        List <User> similarlist = new ArrayList<>();
        for (User startup : users) {
            if (startup.getClass() == Startup.class) {
                Startup startup1 = (Startup) startup;
                if (startup1.checkCriteria(Category)) {
                    similarlist.add(startup);
                }
            }

        }

        return similarlist;
    }


    // this is to get the Y array to display in the Graph, user is a start-up.
    // This is to get the Y array to display in the Graph, user is a start-up.
    public int [] getFinancialData(int year, User user) {


        int[] monthlyData = null;
        if (user.getClass() == Startup.class) {
            Startup startup = (Startup) user;
            FinancialData financialData = startup.getFinancialData();
            List<FinancialEntry> entries = financialData.getEntries();


            // Array to store cumulative profit/loss for each month (1-12).
            monthlyData = new int[12];

            for (FinancialEntry entry : entries) {


                if (entry.getYear() == year) {
                    int month = entry.getMonth(); // Get the month (1 to 12)

                    if (month >= 1 && month <= 12) {
                        monthlyData[month - 1] += entry.getProfitOrLoss(); // Accumulate data for the month
                    }
                }
            }

//            for ( int i=0 ; i < 12  ;i++) {
//                System.out.println( (i +1) +" : " + monthlyData[i]);
//            }

            return monthlyData;
        }

        return monthlyData;

    }


    // Scheduling a meeting
    public void scheduleMeetings ( int userAID, int userBID, Date timeSlot ) {

        Meeting newMeeting = new Meeting( userAID , userBID , timeSlot , "Scheduled");
        this.addMeeting(newMeeting);
        DBHandler.getInstance().addMeeting(newMeeting);

    }

//    public Date convertToDate(String date, String time){
//        try {
//            String dateStr = date + " " + time;
//            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//            Date d = sdf.parse(dateStr);
//            System.out.println("Parsed Date: " + d);
//            return d;
//        }
//        catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }

    public Date processDateTime(String dateString, String timeString) {
        try {
            // Step 1: Convert the date string from Year-Month-Day to Day-Month-Year
            SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MM-yyyy");

            // Parse the input date string and format it to the desired output
            Date parsedDate = inputDateFormat.parse(dateString);
            String updatedDateString = outputDateFormat.format(parsedDate);

            // Step 2: Concatenate the updated date string with the time string
            String dateTimeString = updatedDateString + " " + timeString;

            // Step 3: Convert the concatenated string into a Date object
            SimpleDateFormat finalDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            return finalDateFormat.parse(dateTimeString);
        } catch (ParseException e) {
            e.printStackTrace();
            // Return null if there's an error during parsing
            return null;
        }
    }


    // Method to add a new Meeting
    public void addMeeting(Meeting meeting) {
        meetings.add(meeting);

        System.out.println("Meeting added successfully: " + meeting.getMeetingID());
    }

    // Method to add a new Event
    public void addEvent(Events event) {
        events.add(event);
        System.out.println("Event added successfully: " + event.getName() );
    }

//    // Method to get all Meetings for a specific User
//    public List<Meeting> getMeetingsForUser(int userID) {
//        List<Meeting> userMeetings = new ArrayList<>();
//        for (Meeting meeting : meetings) {
//            if (meeting.getUserAID() == userID || meeting.getUserBID() == userID) {
//                userMeetings.add(meeting);
//            }
//        }
//        return userMeetings;
//    }

    // Method to get all Meetings for a specific User
    public List<Meeting> getMeetingsAsReceiver (int userID) {
        List<Meeting> userMeetings = new ArrayList<>();
        for (Meeting meeting : meetings) {
            if ( meeting.getUserBID() == userID) {
                userMeetings.add(meeting);
                System.out.println(meeting.getMeetingID());
            }
        }
        return userMeetings;
    }

    public List<Meeting> getMeetingsAsSender (int userID) {
        List<Meeting> userMeetings = new ArrayList<>();
        for (Meeting meeting : meetings) {
            if ( meeting.getUserAID() == userID) {
                userMeetings.add(meeting);
            }
        }
        return userMeetings;
    }

    public void updateMeetingStatus ( Meeting meet , String status ) {
        if (meet != null)
        {
            meet.setStatus(status);
            DBHandler.getInstance().updateMeetingStatus(meet.getMeetingID(), status);
        }
    }

    public void addGoal (User user , String description , Date deadline , int financialGoal ) {

        if (user.getClass() == Startup.class) {
            Goals goal = new Goals(user.getUserID(), description, deadline);
            goal.setFinancialGoal(financialGoal); // set the financial amount

            Startup startup = (Startup) user;
            startup.addGoal(goal);
            DBHandler.getInstance().addGoal(goal); // DB entry

        }
    }




    // Useless function I made to blah blah
    // Method to print all Users
    public void printAllUsers() {
        if (users.isEmpty()) {
            System.out.println("No users available.");
        } else {
            for (User user : users) {
                System.out.println(user);
            }
        }
    }

    // Method to print all Meetings
    public void printAllMeetings() {
        if (meetings.isEmpty()) {
            System.out.println("No meetings scheduled.");
        } else {
            for (Meeting meeting : meetings) {
                System.out.println(meeting);
            }
        }
    }

    // Method to print all Events
    public void printAllEvents() {
        if (events.isEmpty()) {
            System.out.println("No events available.");
        } else {
            for (Events event : events) {
                System.out.println(event);
            }
        }
    }


    //////////////////////////// new code ///////////////////////////

    public void AnncouceJob( User user , String title, String description, String category, String status) {
        Job newJob = new Job( user.getUserID() , title, description, category,  status);

        if (user.getClass() == BiggerCompany.class) {
            BiggerCompany biggerCompany =(BiggerCompany) user ;
            biggerCompany.addJob(newJob); // us user ke reference se add the job
            DBHandler.getInstance().addJob(newJob); // new entry in the Database
        }
    }

    public void enterFinancialEntry (User user , int expenses, int income , Date date ) {

        if ( user.getClass() == Startup.class) {
            Startup startup = (Startup) user;
            FinancialData f = startup.getFinancialData() ;
            f.enterData(expenses, income, date);

        }

    }



    //  no repeat in the username or emails
    public boolean checkUsername (String name ) {

        for (User user : users) {
            if (Objects.equals(user.getName(), name)) {
                return true ;
            }
        }

        return false ;

    }

    public boolean checkEmail (String email ) {

        for (User user : users) {
            if (Objects.equals(user.getEmail(), email)) {
                return true ;
            }
        }

        return false ;

    }


    public void addEvent (User user , String name, String description, Date date, String location ) {
        Events event = new Events (user.getUserID() , name , description , date , location ) ;

        this.addEvent(event); // in the array
        DBHandler.getInstance().addEvent(event); // in the DB

    }


    public void addAchievement ( User user , String title, String description ,Date date ){

        if ( user.getClass() == Startup.class) {

            Achievement achievement = new Achievement( user.getUserID() , title , description , date ) ;
            Startup startup = (Startup) user;
            startup.addAchievement(achievement);
            DBHandler.getInstance().addAchievement(achievement);

        }

    }

    public void addService  ( User user , String name, String description, String category, int basePrice  ){

        Service service = new Service( user.getUserID() , name , description , category , basePrice ) ;
        if ( user.getClass() == Startup.class) {
            Startup startup = (Startup) user;
            startup.addService(service);
            DBHandler.getInstance().addService(service);

        }

    }

    public List<Job> searchJobs (String Category) {
        List <Job> list = new ArrayList<>();
        for (User biggerCompany : users) {
            if (biggerCompany.getClass() == BiggerCompany.class) {
                BiggerCompany company = (BiggerCompany) biggerCompany;
                List<Job> listTemp  = company.getJobs();
                // System.out.println(company.getName());
                for (Job temp2 : listTemp) {
                    // System.out.println(temp2.getCategory());
                    if (Objects.equals(temp2.getCategory(), Category)) {
                        list.add(temp2);
                    }
                }
            }
        }

        return list;
    }

    public void applyForJob (Job job , User user , String coverLetter ) {
        JobApplication application = new JobApplication( job.getJobID() , user.getUserID() , coverLetter );

        job.submitApplication(application);
        DBHandler.getInstance().addJobApplication(application);

    }

    public void addNotification ( int UserBID ,String message ,String  type ) {

        // user b is the receiver of notification.

        User user = this.getUser(UserBID);
        Notification notification = new Notification( UserBID, message,  type) ;

        user.receiveNotification (notification) ;
        DBHandler.getInstance().addNotification(notification);

    }

    public String ConvertIntoString(LocalDate value) {
        if (value == null) {
            return null; // Return null if the input value is null
        }
        // Convert LocalDate to java.sql.Date
        java.sql.Date sqlDate = java.sql.Date.valueOf(value);
        // Convert java.sql.Date to a String
        return sqlDate.toString();
    }

}
