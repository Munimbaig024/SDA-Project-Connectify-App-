package org.example.myjavafxapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class StartupCardController {

    @FXML
    private Label StartupDashboardTitle1;

    @FXML
    private Button messageButton;

    @FXML
    private Label showEmailLabel;

    @FXML
    private Label showTeamCountLabel;

    @FXML
    private Button viewButton;

    @FXML
    void MessageButtonOnAction(ActionEvent event) {

    }

    @FXML
    void ViewButtonOnAction(ActionEvent event) {

    }

    public void setData(User user) {

        StartupDashboardTitle1.setText(user.getName());
        showEmailLabel.setText(user.getEmail());
        showTeamCountLabel.setText("Team Count: " + user.getTeamSize());
    }
}
