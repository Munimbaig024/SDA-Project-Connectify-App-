package org.example.myjavafxapp;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import java.net.URL;
import java.util.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class ScheduleMeetingCompany implements Initializable {

    @FXML
    private Label CompanyTitle;

    @FXML
    private Button JobButton;

    @FXML
    private Label StartupDashboardTitle;

    @FXML
    private Label StartupDashboardTitle1;

    @FXML
    private Button acceptButton;

    @FXML
    private Button addMeetingButton;

    @FXML
    private Button chatButton;

    @FXML
    private ImageView companyImageField;

    @FXML
    private TextField emailTextField;

    @FXML
    private DatePicker enterMeetingDate;

    @FXML
    private Button eventbutton;

    @FXML
    private Button logOutButton;

    @FXML
    private Button meetingButton;

    @FXML
    private Button notificationButton;

    @FXML
    private Button rejectButton;

    @FXML
    private Label InvalidDataEntry;

    @FXML
    private ChoiceBox<String> requestCategoryChoiceBox;

    @FXML
    private ChoiceBox<String> sendCategoryChoiceBox;

    @FXML
    private Button similarStartupButton;

    @FXML
    private TextField timeField;

    @FXML
    private Button viewButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // enterMeetingDate.setOnAction(this::printMeetingDate);
        System.out.println("Initialize method started.");
        System.out.println(Connectify.getInstance().currentUser );

        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        System.out.println(user.getUserID());
        List<Meeting> MeetingRequests = Connectify.getInstance().getMeetingsAsReceiver(user.getUserID());
        List<Meeting> MeetingSent = Connectify.getInstance().getMeetingsAsSender(user.getUserID());
        List<User> users = Connectify.getInstance().getUsers();

        List<String> requestsRecieved = new ArrayList<>();
        for(Meeting meeting : MeetingRequests) {
            for(User loopuser : users){
                if(loopuser.getUserID() == meeting.getUserAID()){
                    requestsRecieved.add(loopuser.getName());
                }
            }
        }

        List<String> requestsSent = new ArrayList<>();
        for(Meeting meeting : MeetingSent) {
            for(User loopuser : users){
                if(loopuser.getUserID() == meeting.getUserBID() && !(meeting.getStatus().equalsIgnoreCase("Cancelled"))){
                    requestsSent.add(loopuser.getName());
                }
            }
        }

        requestCategoryChoiceBox.getItems().addAll(requestsRecieved);
        sendCategoryChoiceBox.getItems().addAll(requestsSent);
    }

    private void UpdateRequestSent() {
        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<Meeting> MeetingSent = Connectify.getInstance().getMeetingsAsSender(user.getUserID());
        List<User> users = Connectify.getInstance().getUsers();
        List<Meeting> meetings = Connectify.getInstance().getMeetings();

        for (Meeting meeting : meetings) {
            System.out.println(user.getUserID() + " " + meeting.getUserAID() + " " + meeting.getUserBID() + " " + meeting.getStatus());
        }
        System.out.println();
        for (Meeting meeting : MeetingSent) {
            System.out.println(user.getUserID() + " " + meeting.getUserAID() + " " + meeting.getUserBID() + " " + meeting.getStatus());
        }
        List<String> requestsSent = new ArrayList<>();
        for(Meeting meeting : MeetingSent) {
            for(User loopuser : users){
                if(loopuser.getUserID() == meeting.getUserBID() && !(meeting.getStatus().equalsIgnoreCase("Cancelled"))){
                    requestsSent.add(loopuser.getName());
                }
            }
        }

        sendCategoryChoiceBox.getItems().clear(); // Clear the existing items
        sendCategoryChoiceBox.getItems().addAll(requestsSent); // Add the new items
    }

    @FXML
    void AddMeetingButtonOnAction(ActionEvent event) {
        try {
            System.out.println("AddMeetingButtonOnAction triggered!");

            User userA = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
            if (userA == null) {
                System.out.println("Current user is null!");
                InvalidDataEntry.setText("No user logged in.");
                return;
            }

            if (!Connectify.getInstance().checkEmail(emailTextField.getText())) {
                System.out.println("Invalid email entered.");
                InvalidDataEntry.setText("Invalid Email Address");
                return;
            }

            User userB = null;
            for (User user : Connectify.getInstance().getUsers()) {
                if (user.getEmail().equalsIgnoreCase(emailTextField.getText())) {
                    userB = user;
                    break;
                }
            }

            if (userB == null) {
                System.out.println("Recipient user not found.");
                InvalidDataEntry.setText("User not found.");
                return;
            }

            String date = ConvertIntoString(enterMeetingDate.getValue());
            Date updateddate = Connectify.getInstance().processDateTime(date, timeField.getText());

            Connectify.getInstance().scheduleMeetings(userA.getUserID(), userB.getUserID(), updateddate);
            UpdateRequestSent();
            InvalidDataEntry.setText("Meeting Scheduled Successfully!");

            User myuser = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
            String message = myuser.getName() + "Sent you a \"" + "Meeting Request" + "\"";
            Connectify.getInstance().addNotification(userB.getUserID(), message, "Message");

        } catch (Exception e) {
            e.printStackTrace();
            InvalidDataEntry.setText("An error occurred.");
        }
    }

    private String ConvertIntoString(LocalDate value) {
        if (value == null) {
            return null; // Return null if the input value is null
        }
        // Convert LocalDate to java.sql.Date
        java.sql.Date sqlDate = java.sql.Date.valueOf(value);
        // Convert java.sql.Date to a String
        return sqlDate.toString();
    }

    private void UpdateRequestRecieved() {
        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<Meeting> MeetingRecieved = Connectify.getInstance().getMeetingsAsReceiver(user.getUserID());
        List<User> users = Connectify.getInstance().getUsers();
//        List<Meeting> meetings = Connectify.getInstance().getMeetings();

//        for (Meeting meeting : meetings) {
//            System.out.println(user.getUserID() + " " + meeting.getUserAID() + " " + meeting.getUserBID() + " " + meeting.getStatus());
//        }
//        System.out.println();
//        for (Meeting meeting : MeetingRecieved) {
//            System.out.println(user.getUserID() + " " + meeting.getUserAID() + " " + meeting.getUserBID() + " " + meeting.getStatus());
//        }

        List<String> requestsRecieved = new ArrayList<>();
        for(Meeting meeting : MeetingRecieved) {
            for(User loopuser : users){
                if(loopuser.getUserID() == meeting.getUserAID() && (meeting.getStatus().equalsIgnoreCase("Scheduled"))){
                    requestsRecieved.add(loopuser.getName());
                }
            }
        }

        requestCategoryChoiceBox.getItems().clear();
        requestCategoryChoiceBox.getItems().addAll(requestsRecieved);
    }

    @FXML
    public void rejectButtonOnAction(ActionEvent event) {
        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<Meeting> MeetingRecieved = Connectify.getInstance().getMeetingsAsReceiver(user.getUserID());
        List<User> users = Connectify.getInstance().getUsers();
        String user_name = requestCategoryChoiceBox.getValue();

        Meeting m1 = null;
        for (Meeting meeting : MeetingRecieved) {
            for (User myuser : users) {
                if (myuser.getName().equals(user_name)) {
                    m1 = meeting;
                    break;
                }
            }
        }
        Connectify.getInstance().updateMeetingStatus(m1, "Cancelled");
        UpdateRequestRecieved();
    }

    @FXML
    public void acceptButtonOnAction(ActionEvent event) {
        User user = Connectify.getInstance().getUser(Connectify.getInstance().currentUser);
        List<Meeting> MeetingRecieved = Connectify.getInstance().getMeetingsAsReceiver(user.getUserID());
        List<User> users = Connectify.getInstance().getUsers();
        String user_name = requestCategoryChoiceBox.getValue();

        Meeting m1 = null;
        for (Meeting meeting : MeetingRecieved) {
            for (User myuser : users) {
                if (myuser.getName().equals(user_name)) {
                    m1 = meeting;
                    break;
                }
            }
        }
        Connectify.getInstance().updateMeetingStatus(m1, "Completed");
        UpdateRequestRecieved();
    }

    private void loadFXML(String fxmlFile, int width, int height) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to load screen");
            alert.setContentText("Failed to load: " + fxmlFile);
            alert.showAndWait();
        }
    }

    @FXML
    public void NotificationButtonOnAction(ActionEvent event) {
        loadFXML("notificationCompany.fxml", 872, 586);

        Stage currentStage = (Stage) notificationButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void SimilarStartupButtonOnAction(ActionEvent event) {
        loadFXML("findSimilarStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) similarStartupButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void MeetingButtonOnAction(ActionEvent event)
    {
        loadFXML("scheduleMeetingCompany.fxml", 872, 586);
        Stage currentStage = (Stage) meetingButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void ChatButtonOnAction(ActionEvent event)
    {
        loadFXML("ChatStartupCompany.fxml", 872, 586);
        Stage currentStage = (Stage) chatButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    public void LogOutButtonOnAction(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), 600, 405);
            stage.setScene(scene);
            TransitionHelper.applyFadeTransition(scene.getRoot());
            stage.show();

            // Close the current stage
            Stage currentStage = (Stage) logOutButton.getScene().getWindow();
            // Apply fade-out transition to the current scene
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);

            // Set an action on fade transition completion
            fadeOut.setOnFinished(e -> currentStage.close());

            // Start the fade-out transition
            fadeOut.play();
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Logout Error");
            alert.setContentText("Unable to logout and switch to the login screen.");
            alert.showAndWait();
        }
    }

    @FXML
    void EventButtonOnAction(ActionEvent event) {
        loadFXML("setupEvent.fxml", 872, 586);
        Stage currentStage = (Stage) eventbutton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void JobButtonOnAction(ActionEvent event) {
        loadFXML("announceJobCompany.fxml", 872, 586);
        Stage currentStage = (Stage) JobButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }

    @FXML
    void ViewButtonOnAction(ActionEvent event) {
        loadFXML("viewProfileCompany.fxml", 872, 586);
        Stage currentStage = (Stage) viewButton.getScene().getWindow();
        // Apply fade-out transition to the current scene
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(1), currentStage.getScene().getRoot());
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);

        // Set an action on fade transition completion
        fadeOut.setOnFinished(e -> currentStage.close());

        // Start the fade-out transition
        fadeOut.play();
    }
}

