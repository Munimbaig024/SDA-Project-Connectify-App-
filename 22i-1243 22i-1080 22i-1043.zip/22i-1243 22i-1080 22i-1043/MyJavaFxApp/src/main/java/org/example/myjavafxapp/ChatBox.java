package org.example.myjavafxapp;

import java.util.ArrayList;
import java.util.List;

public class ChatBox {

    // List to store multiple conversations
    private List<Conversation> conversations;

    // Constructor
    public ChatBox() {
        conversations = new ArrayList<>();
    }

    // Method to add a new conversation to the chat box
    public Conversation addConversation(int userAID, int userBID ) {
        Conversation newConversation = new Conversation(userAID, userBID);

        conversations.add(newConversation);

        System.out.println("New conversation created between User " + userAID + " and User " + userBID);
        return newConversation;
    }

    // Method to display all conversations in the chatbox
    public void displayAllConversations() {

        System.out.println("Displaying all conversations:");
        for (Conversation conversation : conversations) {
            conversation.displayConversation();
            System.out.println("-------------------------------------");
        }
    }

    public void setConversations(List<Conversation> conversations) {
        this.conversations = conversations;
    }


    // Get the number of conversations

    public int getNumberOfConversations() {
        return conversations.size();
    }

    public Conversation getConversation(int userAID, int userBID) {
        for (Conversation conversation : conversations) {
            if ( (conversation.getUserAID() == userAID && conversation.getUserBID() == userBID) ||
                    (conversation.getUserAID() == userBID && conversation.getUserBID() == userAID)  ) {
                return conversation;
            }
        }


        return null;
    }

//    // Main method for demonstration
//    public static void main(String[] args) {
//        // Create a ChatBox instance
//        ChatBox chatBox = new ChatBox();
//
//        // Add conversations
//        chatBox.addConversation(1, 2);
//        chatBox.addConversation(3, 4);
//
//        // Add messages to the first conversation
//        chatBox.conversations.get(0).addMessage("Hello from User 1", 1);
//        chatBox.conversations.get(0).addMessage("Hi User 1, this is User 2", 2);
//
//        // Add messages to the second conversation
//        chatBox.conversations.get(1).addMessage("Hey User 3, how's it going?", 3);
//        chatBox.conversations.get(1).addMessage("All good, User 4 here!", 4);
//
//        // Display all conversations
//        chatBox.displayAllConversations();
//
//        // Display the total number of conversations
//        System.out.println("Total number of conversations: " + chatBox.getNumberOfConversations());
//    }

}
