package org.example.myjavafxapp;

import javafx.animation.FadeTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class TransitionHelper {
    public static void applyFadeTransition(Node node) {
        FadeTransition fade = new FadeTransition();
        fade.setDuration(Duration.seconds(1));  // 1-second fade duration
        fade.setFromValue(0);  // Start fully transparent
        fade.setToValue(1);    // End fully visible
        fade.setNode(node);
        fade.play();
    }
}
